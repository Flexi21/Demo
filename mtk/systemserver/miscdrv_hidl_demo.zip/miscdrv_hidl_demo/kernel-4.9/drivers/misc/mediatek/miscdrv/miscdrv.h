#ifndef __MISCDRV_H_
#define __MISCDRV_H_

/************  Ioctl cmd part Begin ****************/
#define MISCDRV_SET_IO_TEST       _IOW('m', 0x1, int)
#define MISCDRV_GET_IO_TEST       _IOW('m', 0x2, int)


/************  Ioctl cmd part End ******************/

struct miscdrv_priv {
	int version;
};


















#endif
