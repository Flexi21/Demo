#include <linux/i2c.h>
#include <linux/module.h>
#include <linux/platform_device.h>
#include <linux/delay.h>
#include <linux/string.h>
#include <linux/ctype.h>
#include <linux/leds.h>
#include <linux/workqueue.h>
#include <linux/pm_wakeup.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <mt-plat/mtk_pwm.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>


#include "miscdrv.h"

#define MISCDRV_DEVICE "miscdrv"
#define FUNC_ENTRY		pr_info("%s Entry !",__func__);

#define MISCDRV_DEBUG  //just for test

#if defined(MISCDRV_DEBUG) 
static char str_buf[50] = {0};
#endif

static int miscdrv_open(struct inode *inode, struct file *filp)
{
	FUNC_ENTRY
	
	return 0;
}

static ssize_t miscdrv_read(struct file *filp, char __user *buf,
									size_t count, loff_t *f_pos)
{
	FUNC_ENTRY

	#if defined(MISCDRV_DEBUG)
	if (copy_to_user(buf, str_buf + *f_pos, count)) 
		pr_err("miscdrv: copy to user failed!\n");
	
	pr_info("miscdrv: str: %s \n",str_buf);
	#endif

	return count;
}

static ssize_t miscdrv_write(struct file *filp, const char __user *buf,
										     size_t count, loff_t *f_pos)
{
	FUNC_ENTRY
	
	#if defined(MISCDRV_DEBUG)
	memset(str_buf, 0x00, sizeof(str_buf));
	if (copy_from_user(str_buf, buf, count))
		pr_err("miscdrv: copy_from_user failed!\n");
		
	pr_info("miscdrv: str: %s \n", str_buf);
	#endif

	return count;
}

static int miscdrv_release(struct inode *inode, struct file *filp)
{
	FUNC_ENTRY

	return 0;
}


static long miscdrv_ioctl(struct file *file, unsigned int cmd,
												 unsigned long arg)
{
	int ret;
	int temp = 1;

	FUNC_ENTRY
	
	pr_info("miscdrv_ioctl cmd:0x%x",cmd);
	
	switch (cmd) {
		case MISCDRV_SET_IO_TEST:
			if (copy_from_user(&temp, (void __user *)arg, sizeof(temp))) {
				pr_err("%s : MISCDRV_SET_IO_TEST copy_from_user failed!\n",__func__);
				ret = -EFAULT;
				goto EXIT;
			}
			pr_info("%s: MISCDRV_SET_IO_TEST value:%d ",__func__, temp);
			
		break;
		case MISCDRV_GET_IO_TEST:
			if (copy_to_user((unsigned int __user *)arg, &temp, sizeof(temp))) {
				pr_err("%s : MISCDRV_GET_IO_TEST copy_to_user failed!\n",__func__);
				ret = -EFAULT;
				goto EXIT;
			}
			pr_info("%s: MISCDRV_GET_IO_TEST value:%d ",__func__, temp);
			
		break;

		default:
			pr_err("%s : CMD: %d No Found!!!\n",__func__, cmd);
		break;
	}; 

 EXIT:
 
	return 0;
};

#ifdef CONFIG_COMPAT
static long miscdrv_compat_ioctl(struct file *file, unsigned int cmd,
												 unsigned long arg)
{
	FUNC_ENTRY

	return 0;
}
#endif


static struct file_operations miscdrv_fops = {
	.owner = THIS_MODULE,
	.open  = miscdrv_open,
	.read  = miscdrv_read,
	.write = miscdrv_write,	
	.release = miscdrv_release,
	.unlocked_ioctl = miscdrv_ioctl,
#ifdef CONFIG_COMPAT
	.compat_ioctl = miscdrv_compat_ioctl,
#endif
};


static struct miscdevice miscdrv = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "miscdrv",
	.fops = &miscdrv_fops,
};


#ifdef CONFIG_OF
static const struct of_device_id _miscdrv_of_ids[] = {
	{.compatible = "misc,miscdrv",},
	{},
};
MODULE_DEVICE_TABLE(of, _miscdrv_of_ids);
#endif

//debug part
static ssize_t miscdrv_test_show(struct device* dev,
                      struct device_attribute *attr, char* buf)
{
	int len = 0;
	
	FUNC_ENTRY

	len += snprintf(buf+len, PAGE_SIZE-len, "miscdrv_test_show \r\n"); 

	return len;
}

static ssize_t misc_test_store(struct device* dev,
                   struct device_attribute *attr,const char* buf, size_t len)
{
	FUNC_ENTRY	
	
	return len;
}

static DEVICE_ATTR(miscdrv_test, 0664, miscdrv_test_show, misc_test_store);

static struct attribute *miscdrv_attrs[] = {
	&dev_attr_miscdrv_test.attr,
	NULL,
};

static struct attribute_group miscdrv_group = {
	.attrs = miscdrv_attrs
};

static int miscdrv_suspend(struct device *dev)
{
	FUNC_ENTRY
	
	return 0;
}

static int miscdrv_resume(struct device *dev)
{
	FUNC_ENTRY

	return 0;	
}


static SIMPLE_DEV_PM_OPS(miscdrv_pm_ops, miscdrv_suspend, miscdrv_resume);

static int miscdrv_remove(struct platform_device *pdev)
{
	FUNC_ENTRY
	
	misc_deregister(&miscdrv);
	return 0;
}

static int miscdrv_probe(struct platform_device *pdev)
{
	int err;
	struct miscdrv_priv *pdata;
	
	FUNC_ENTRY
	
	pdata = devm_kzalloc(&pdev->dev,
				sizeof(*pdata), GFP_KERNEL);
	if (!pdata) {
		pr_err("%s : allloc miscdrv_priv data failed !\n",__func__);
		return -ENOMEM;
	}
	
	err = misc_register(&miscdrv);
	if (unlikely(err)) {
		pr_info("miscdrv: misc_register failed! \n");
		return err;
	}
	
	err = sysfs_create_group(&pdev->dev.kobj, &miscdrv_group);
	if (err < 0) {
		pr_err("miscdrv: unable to create miscdrv attribute file\n");
		return err;
	}
	
	pdata->version = 0x01;
	platform_set_drvdata(pdev, pdata);

	return 0;
}

static struct platform_driver miscdrv_driver = {
	.driver = {
		.name = MISCDRV_DEVICE,
		.owner	= THIS_MODULE,
		.of_match_table = of_match_ptr(_miscdrv_of_ids),
		.pm = &miscdrv_pm_ops,
	},
	.probe = miscdrv_probe,
	.remove = miscdrv_remove,
};
//module_platform_driver(miscdrv_driver);

static int __init miscdrv_init(void)
{
	int ret;
	
	ret = platform_driver_register(&miscdrv_driver);
	if (ret != 0) {
		pr_err("miscdrv: unable to register miscdrv driver.\n");
		return -1;
	}
	
	return 0;
}

static void __exit miscdrv_exit(void)
{
	platform_driver_unregister(&miscdrv_driver);
}

module_init(miscdrv_init);
module_exit(miscdrv_exit);
MODULE_LICENSE("GPL");
