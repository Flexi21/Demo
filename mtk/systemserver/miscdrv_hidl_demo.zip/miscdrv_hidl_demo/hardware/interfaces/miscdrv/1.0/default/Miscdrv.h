#ifndef ANDROID_HARDWARE_MISCDRV_V1_0_MISCDRV_H
#define ANDROID_HARDWARE_MISCDRV_V1_0_MISCDRV_H

#include <android/hardware/miscdrv/1.0/IMiscdrv.h>
#include <hidl/MQDescriptor.h>
#include <hidl/Status.h>
#include <hardware/miscdrv.h>

namespace android {
namespace hardware {
namespace miscdrv {
namespace V1_0 {
namespace implementation {

using ::android::hardware::hidl_array;
using ::android::hardware::hidl_memory;
using ::android::hardware::hidl_string;
using ::android::hardware::hidl_vec;
using ::android::hardware::Return;
using ::android::hardware::Void;
using ::android::sp;

struct Miscdrv : public IMiscdrv {
    // Methods from IMiscdrv follow.
    Return<void> miscdrvTest() override;

    // Methods from ::android::hidl::base::V1_0::IBase follow.

};

// FIXME: most likely delete, this is only for passthrough implementations
 extern "C" IMiscdrv* HIDL_FETCH_IMiscdrv(const char* name);

}  // namespace implementation
}  // namespace V1_0
}  // namespace miscdrv
}  // namespace hardware
}  // namespace android

#endif  // ANDROID_HARDWARE_MISCDRV_V1_0_MISCDRV_H
