#include "Miscdrv.h"
#include <log/log.h>

namespace android {
namespace hardware {
namespace miscdrv {
namespace V1_0 {
namespace implementation {

struct miscdrv_device_t *MiscdrvDev;

#define TAG          "miscdrv hal :"

// Methods from IMiscdrv follow.
Return<void> Miscdrv::miscdrvTest() {
    // TODO implement
    ALOGE(TAG "miscdrvTest\n");
    
    MiscdrvDev->miscdrv_test("miscdrvTest hal to module! \n");
    
    return Void();
}

miscdrv_device_t *getMiscDrvDdevice(void)
{
    miscdrv_device_t *miscdrvDevice;
    const hw_module_t* hwModule = NULL;
    
    int ret = hw_get_module(MISCDRV_HARDWARE_MODULE_ID, &hwModule);
    if (ret == 0) {
        ret = hwModule->methods->open(hwModule, NULL,
            reinterpret_cast<hw_device_t**>(&miscdrvDevice));
        if (ret != 0) {
            ALOGE(TAG "miscdrv_open %s failed: %d", MISCDRV_HARDWARE_MODULE_ID, ret);
        }
    } else {
        ALOGE(TAG "hw_get_module %s failed: %d", MISCDRV_HARDWARE_MODULE_ID, ret);
    }
    
    if (ret == 0) {
        return miscdrvDevice;
    } else {
        ALOGE(TAG "MiscDrv passthrough failed to load legacy HAL.");
        return nullptr;
    }
}

// Methods from ::android::hidl::base::V1_0::IBase follow.

IMiscdrv* HIDL_FETCH_IMiscdrv(const char* /* name */) {

    ALOGE(TAG "HIDL_FETCH_IMiscdrv\n");

     MiscdrvDev = getMiscDrvDdevice();
     if (MiscdrvDev == nullptr)
         ALOGE(TAG "getMiscDrvDdevice error! \n");
    return new Miscdrv();
}

}  // namespace implementation
}  // namespace V1_0
}  // namespace miscdrv
}  // namespace hardware
}  // namespace android
