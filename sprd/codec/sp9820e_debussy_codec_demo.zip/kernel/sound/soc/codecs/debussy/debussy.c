#include <linux/version.h>
#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/firmware.h>
#include <linux/gpio.h>
#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/pm.h>
#include <linux/string.h>
#include <sound/core.h>
#include <sound/initval.h>
#include <sound/soc.h>
#include <sound/tlv.h>
#include <linux/regmap.h>
#include <linux/delay.h>

#include "debussy.h"
#include "debussy_intf.h"
#include "debussy_snd_ctrl.h"
#ifdef ENABLE_GENETLINK
#include "debussy_genetlink.h"
#endif
#ifdef ENABLE_KWS
#include "debussy_kws.h"
#endif
#include "debussy_customer.h"
#ifdef DOWNLOAD_FW_USING_HEADER_FILE
#include "debussy.bin.h"
#else
static const unsigned char *debussy_bin = NULL;
#endif

#ifndef DRIVER_COMMAND_VERSION
#define DRIVER_COMMAND_VERSION  (0x00000000)        // For Old Version
#endif

#define DEBUSSY_FW_PATH         "./"
#define DEBUSSY_FW_ADDR         (0x0)
#define DEBUSSY_FW_NAME_SIZE    (256)
#define DEBUSSY_FW_VER_OFFSET   (0x00002014)
#define ENABLE_CODEC_DAPM_CB

#define DEBUSSY_RATES SNDRV_PCM_RATE_16000
#define DEBUSSY_FORMATS (SNDRV_PCM_FMTBIT_S16_LE | SNDRV_PCM_FMTBIT_S24_LE | SNDRV_PCM_FMTBIT_S32_LE)

struct debussy_priv* p_debussy_priv = NULL;
//extern void set_debussy_version(u32 version);//Eric.Hu add for check debussy version.
extern int debussy_cdev_init(void *priv_data);
extern void debussy_cdev_exit(void);
#ifdef ENABLE_KWS
extern int debussy_kws_init(struct debussy_priv* debussy);
#endif

static void _debussy_hif_cali(struct debussy_priv* debussy);

#ifdef ENABLE_DEBUSSY_I2C_REGMAP
static bool debussy_readable(struct device *dev, unsigned int reg)
{
    return true;
}

static bool debussy_writeable(struct device *dev, unsigned int reg)
{
    return true;
}

static bool debussy_volatile(struct device *dev, unsigned int reg)
{
    return true;
}

static bool debussy_precious(struct device *dev, unsigned int reg)
{
    return false;
}

const struct regmap_config debussy_i2c_regmap = {
    .reg_bits = 32,
    .val_bits = 32,
    .reg_stride = 4,

    //.cache_type = REGCACHE_NONE,
    .cache_type = REGCACHE_RBTREE,
    .reg_format_endian = REGMAP_ENDIAN_BIG,
    #if LINUX_VERSION_CODE <= KERNEL_VERSION(3,13,11)
    // For Android 5.1
    .val_format_endian = REGMAP_ENDIAN_NATIVE,
    #else
    .val_format_endian = REGMAP_ENDIAN_LITTLE,
    #endif

    .max_register = (unsigned int) -1,
    .readable_reg = debussy_readable,
    .writeable_reg = debussy_writeable,
    .volatile_reg = debussy_volatile,
    .precious_reg = debussy_precious,
};
#endif

static ssize_t _debussy_download_firmware(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_download_firmware_fops = {
    .open = simple_open,
    .write = _debussy_download_firmware,
};

static ssize_t _debussy_reset_chip(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reset_chip_fops = {
    .open = simple_open,
    .write = _debussy_reset_chip,
};

static ssize_t _debussy_reset_gpio_pull_down(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reset_gpio_pull_down_fops = {
    .open = simple_open,
    .write = _debussy_reset_gpio_pull_down,
};

static ssize_t _debussy_reset_gpio_pull_up(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reset_gpio_pull_up_fops = {
    .open = simple_open,
    .write = _debussy_reset_gpio_pull_up,
};

static ssize_t _debussy_mcu_hold(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_mcu_hold_fops = {
    .open = simple_open,
    .write = _debussy_mcu_hold,
};

static ssize_t _debussy_get_fw_version(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_get_fw_version_fops = {
    .open = simple_open,
    .write = _debussy_get_fw_version,
};

static ssize_t _debussy_reg_get(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reg_get_fops = {
    .open = simple_open,
    .write = _debussy_reg_get,
};

static ssize_t _debussy_reg_put(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reg_put_fops = {
    .open = simple_open,
    .write = _debussy_reg_put,
};

static ssize_t _debussy_hif_calibration(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_hif_calibration_fops = {
    .open = simple_open,
    .write = _debussy_hif_calibration,
};

static loff_t _debussy_reg_seek(struct file *file,
    loff_t p, int orig);
static ssize_t _debussy_reg_read(struct file* file,
    char __user* user_buf,
    size_t count, loff_t* ppos);
static ssize_t _debussy_reg_write(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos);
static const struct file_operations debussy_reg_fops = {
    .open = simple_open,
    .llseek = _debussy_reg_seek,
    .read = _debussy_reg_read,
    .write = _debussy_reg_write,
};

static const struct i2c_device_id igo_i2c_id[] = {
    { "debussy", 0 },
    {}
};
MODULE_DEVICE_TABLE(i2c, igo_i2c_id);

static const struct of_device_id debussy_of_match[] = {
    { .compatible = "intelligo,debussy" },
    {},
};
MODULE_DEVICE_TABLE(of, debussy_of_match);

static void _debussy_reset_chip_ctrl(struct device* dev, uint8_t free_run, uint8_t usingDelayThread)
{
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(dev));
    struct i2c_client *client = i2c_verify_client(debussy->dev);

    atomic_set(&debussy->maskConfigCmd, 1);

#ifdef ENABLE_REFERENCE_COUNT
    #ifdef ENABLE_CODEC_DAPM_CB
    if (free_run)
        atomic_set(&debussy->referenceCount, 0);
    else
        atomic_set(&debussy->referenceCount, 1);
    #else
    atomic_set(&debussy->referenceCount, 0);
    #endif
#else
    atomic_set(&debussy->referenceCount, 1);
#endif

    if (gpio_is_valid(debussy->reset_gpio)) {
#ifdef DEBUSSY_TYPE_PSRAM
        igo_i2c_write(client, 0x2A000018, 1);
        igo_i2c_write(client, 0x2A00003C, 0xFE83FFFF);
        usleep_range(4999, 5000);
#endif
        gpio_direction_output(debussy->reset_gpio, GPIO_LOW);
        gpio_set_value(debussy->reset_gpio, GPIO_LOW);

        if (debussy->reset_hold_time >= 20) {
            usleep_range(debussy->reset_hold_time * 1000 - 1, debussy->reset_hold_time * 1000);
        }
        else {
            msleep(debussy->reset_hold_time);
        }

        gpio_direction_output(debussy->reset_gpio, GPIO_HIGH);
        gpio_set_value(debussy->reset_gpio, GPIO_HIGH);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);

#ifdef DEBUSSY_TYPE_PSRAM
        igo_i2c_write(client, 0x2a00003c, 0x830001);
        igo_i2c_write(client, 0x2a013024, 0xc00e00f5);
        igo_i2c_write(client, 0x2a013028, 0);
        igo_i2c_write(client, 0x2a01302c, 0);
        igo_i2c_write(client, 0x2a013030, 0);
        igo_i2c_write(client, 0x2a013034, 0);
#endif  /* end of DEBUSSY_TYPE_PSRAM */

        if (free_run) {
            igo_i2c_write(client, 0x2A000018, 0);
        }

#ifdef IGO_STANDBY_INSTEAD_OF_DELAY_WORK
        if (0 == usingDelayThread) {
            msleep(debussy->reset_release_time);
            igo_spi_intf_enable(1);

            dev_info(dev, "%s: Reset debussy chip done\n", __func__);
        }
        else {
            dev_info(dev, "%s: Start standby delay work - %d\n", __func__, debussy->reset_release_time * HZ / 1000 + 1);
            schedule_delayed_work(&debussy->standby_work,
                                  debussy->reset_release_time * HZ / 1000 + 1);
        }
#else
        msleep(debussy->reset_release_time);
        igo_spi_intf_enable(1);

        dev_info(dev, "%s: Reset debussy chip done\n", __func__);
#endif
    }
    else {
        dev_err(dev, "%s: Reset GPIO-%d is invalid\n", __func__, debussy->reset_gpio);
    }
}

static ssize_t _debussy_reset_chip(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;

    mutex_lock(&debussy->igo_ch_lock);
    debussy->mcu_hold(debussy->dev, 0);
    debussy->reset_chip(debussy->dev, 1, 0);
    mutex_unlock(&debussy->igo_ch_lock);

    return count;
}

static ssize_t _debussy_reset_gpio_pull_down(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;

    if (gpio_is_valid(debussy->reset_gpio)) {
        atomic_set(&debussy->maskConfigCmd, 1);
#ifdef ENABLE_REFERENCE_COUNT
        atomic_set(&debussy->referenceCount, 0);
#else
        atomic_set(&debussy->referenceCount, 1);
#endif
        gpio_direction_output(debussy->reset_gpio, GPIO_LOW);
        gpio_set_value(debussy->reset_gpio, GPIO_LOW);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);
    }
    else {
        dev_err(debussy->dev, "%s: Reset GPIO-%d is invalid\n", __func__, debussy->reset_gpio);
    }

    return count;
}

static ssize_t _debussy_reset_gpio_pull_up(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    struct i2c_client* client = i2c_verify_client(debussy->dev);

    if (gpio_is_valid(debussy->reset_gpio)) {
        gpio_direction_output(debussy->reset_gpio, GPIO_HIGH);
        gpio_set_value(debussy->reset_gpio, GPIO_HIGH);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);

#ifdef DEBUSSY_TYPE_PSRAM
        igo_i2c_write(client, 0x2a00003c, 0x830001);
        igo_i2c_write(client, 0x2a013024, 0xc00e00f5);
        igo_i2c_write(client, 0x2a013028, 0);
        igo_i2c_write(client, 0x2a01302c, 0);
        igo_i2c_write(client, 0x2a013030, 0);
        igo_i2c_write(client, 0x2a013034, 0);
#endif  /* end of DEBUSSY_TYPE_PSRAM */

        igo_i2c_write(client, 0x2A000018, 0);
        msleep(debussy->reset_release_time);
        igo_spi_intf_enable(1);
    }
    else {
        dev_err(debussy->dev, "%s: Reset GPIO-%d is invalid\n", __func__, debussy->reset_gpio);
    }

    return count;
}

static void _debussy_mcu_hold_ctrl(struct device* dev, uint32_t hold)
{
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(dev));

    if (gpio_is_valid(debussy->mcu_hold_gpio)) {
#ifdef DEBUSSY_TYPE_PSRAM
        gpio_direction_output(debussy->mcu_hold_gpio, GPIO_HIGH);
#else
        gpio_direction_output(debussy->mcu_hold_gpio, hold ? GPIO_HIGH : GPIO_LOW);
        dev_info(dev, "%s: MCU Hold - Level-%d\n", __func__, hold);
#endif
        usleep_range(499, 500);
    }
    else {
        dev_err(debussy->dev, "%s: MCU Hold GPIO-%d is invalid\n", __func__, debussy->mcu_hold_gpio);
    }
}

static ssize_t _debussy_mcu_hold(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    unsigned int data, position;
    char *input_data;

    if ((input_data = devm_kzalloc(debussy->dev, count + 1, GFP_KERNEL)) == NULL) {
        dev_err(debussy->dev, "%s: alloc fail\n", __func__);
        return -EFAULT;
    }

    if (copy_from_user(input_data, user_buf, count)) {
        devm_kfree(debussy->dev, input_data);
        return -EFAULT;
    }

    position = strcspn(input_data, "1234567890abcdefABCDEF");
    data = simple_strtoul(&input_data[position], NULL, 10);
    debussy->mcu_hold(debussy->dev, data ? 1 : 0);
    devm_kfree(debussy->dev, input_data);

    return count;
}

static ssize_t _debussy_get_fw_version(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    uint32_t fw_ver = 0;
    uint32_t fw_subver = 0;

    mutex_lock(&debussy->igo_ch_lock);
    igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &fw_ver);
	//set_debussy_version(fw_ver); //Eric.Hu add.
    dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", fw_ver);
    igo_ch_read(debussy->dev, IGO_CH_FW_SUB_VER_ADDR, &fw_subver);
    dev_info(debussy->dev, "CHIP FW SUB_VER: 0x%08X\n", fw_subver);
    mutex_unlock(&debussy->igo_ch_lock);

    return count;
}

// Usage: echo address > /d/debussy/reg_get
static ssize_t _debussy_reg_get(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    struct i2c_client* client;
    unsigned int reg, data, position;
    char *input_data;

    client = i2c_verify_client(debussy->dev);

    if ((input_data = devm_kzalloc(debussy->dev, count + 1, GFP_KERNEL)) == NULL) {
        dev_err(debussy->dev, "%s: alloc fail\n", __func__);
        return -EFAULT;
    }

    if (copy_from_user(input_data, user_buf, count)) {
        devm_kfree(debussy->dev, input_data);
        return -EFAULT;
    }

    position = strcspn(input_data, "1234567890abcdefABCDEF");               // find first number
    reg = simple_strtoul(&input_data[position], NULL, 16);
    mutex_lock(&debussy->igo_ch_lock);
    igo_i2c_read(client, reg, &data);
    mutex_unlock(&debussy->igo_ch_lock);
    dev_info(debussy->dev, "%s: Reg0x%X = 0x%X\n", __func__, reg, data);
    devm_kfree(debussy->dev, input_data);

    return count;
}

// Usage: echo address, data > /d/debussy/reg_put
static ssize_t _debussy_reg_put(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    struct i2c_client* client;
    unsigned int reg, data;
    size_t position;
    char *input_data, *next_data;

    client = i2c_verify_client(debussy->dev);

    if ((input_data = devm_kzalloc(debussy->dev, count + 1, GFP_KERNEL)) == NULL) {
        dev_err(debussy->dev, "%s: alloc fail\n", __func__);
        return -EFAULT;
    }

    if (copy_from_user(input_data, user_buf, count)) {
        devm_kfree(debussy->dev, input_data);
        return -EFAULT;
    }

    dev_info(debussy->dev, "%s: input_data = %s\n", __func__, input_data);

    position = strcspn(input_data, "1234567890abcdefABCDEF");               // find first number
    reg = simple_strtoul(&input_data[position], &next_data, 16);
    position = strcspn(next_data, "1234567890abcdefABCDEF");                // find next number
    data = simple_strtoul(&next_data[position], NULL, 16);
    dev_info(debussy->dev, "%s: reg = 0x%X, data = 0x%X\n", __func__, reg, data);

    mutex_lock(&debussy->igo_ch_lock);
    igo_i2c_write(client, reg, data);
    devm_kfree(debussy->dev, input_data);
    mutex_unlock(&debussy->igo_ch_lock);

    return count;
}

// Usage: echo address, data > /d/debussy/hif_cali
static ssize_t _debussy_hif_calibration(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    uint32_t fw_ver;

    mutex_lock(&debussy->igo_ch_lock);

    if (IGO_CH_STATUS_DONE == igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &fw_ver)) {
        // Calibration
		//set_debussy_version(fw_ver); //Eric.Hu add.
        dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", fw_ver);
		//set_debussy_version(fw_ver); //Eric.Hu add.
        _debussy_hif_cali(debussy);
    }

    mutex_unlock(&debussy->igo_ch_lock);

    return count;
}

static loff_t _debussy_reg_seek(struct file *file,
    loff_t p, int orig)
{
    struct debussy_priv* debussy = file->private_data;

    debussy->reg_address = p & 0xFFFFFFFC;
    dev_info(debussy->dev, "%s - 0x%X\n", __func__, debussy->reg_address);

    return p;
}

static ssize_t _debussy_reg_read(struct file* file,
    char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    struct i2c_client* client;
    uint32_t *input_data;

    client = i2c_verify_client(debussy->dev);
    dev_info(debussy->dev, "%s -\n", __func__);
    count &= 0xFFFFFFFC;

    if (count) {
        if ((input_data = (uint32_t *) devm_kzalloc(debussy->dev, count, GFP_KERNEL)) == NULL) {
            dev_err(debussy->dev, "%s: alloc fail\n", __func__);
            return -EFAULT;
        }

        mutex_lock(&debussy->igo_ch_lock);
        igo_i2c_read_buffer(client, debussy->reg_address, input_data, count >> 4);
        mutex_unlock(&debussy->igo_ch_lock);

        if (copy_to_user(user_buf, (char *) input_data, count)) {
            count = -EFAULT;
        }

        devm_kfree(debussy->dev, input_data);
    }

    return count;
}

static ssize_t _debussy_reg_write(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy = file->private_data;
    struct i2c_client* client;
    uint32_t *input_data;

    client = i2c_verify_client(debussy->dev);
    dev_info(debussy->dev, "%s -\n", __func__);
    count &= 0xFFFFFFFC;

    if (count) {
        if ((input_data = (uint32_t *) devm_kzalloc(debussy->dev, count, GFP_KERNEL)) == NULL) {
            dev_err(debussy->dev, "%s: alloc fail\n", __func__);
            return -EFAULT;
        }

        if (copy_from_user((char *) input_data, user_buf, count)) {
            count = -EFAULT;
        }
        else {
            mutex_lock(&debussy->igo_ch_lock);
            igo_i2c_write_buffer(client, debussy->reg_address, input_data, count >> 2);
            debussy->reg_address += count;
            mutex_unlock(&debussy->igo_ch_lock);
        }

        devm_kfree(debussy->dev, input_data);
    }

    return count;
}

static ssize_t _debussy_download_firmware(struct file* file,
    const char __user* user_buf,
    size_t count, loff_t* ppos)
{
    struct debussy_priv* debussy;

    debussy = file->private_data;
    dev_info(debussy->dev, "%s\n", __func__);

#ifdef IGO_DUMMY_DRIVER
    // NOP
#else
    queue_work(debussy->debussy_wq, &debussy->fw_work);
#endif

    return count;
}

static int debussy_hw_params(struct snd_pcm_substream* substream,
    struct snd_pcm_hw_params* params, struct snd_soc_dai* dai)
{
    return 0;
}

static int debussy_set_dai_fmt(struct snd_soc_dai* dai, unsigned int fmt)
{
    return 0;
}

static int debussy_set_dai_sysclk(struct snd_soc_dai* dai,
    int clk_id, unsigned int freq, int dir)
{
    return 0;
}

static int debussy_set_dai_pll(struct snd_soc_dai* dai, int pll_id, int source,
    unsigned int freq_in, unsigned int freq_out)
{
    return 0;
}

static void debussy_shutdown(struct snd_pcm_substream* stream,
    struct snd_soc_dai* dai)
{
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(dai->codec->dev));

    pr_info("%s\n", __func__);

     mutex_lock(&debussy->igo_ch_lock);
    // atomic_set(&debussy->maskConfigCmd, 1);
    igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
    dev_info(debussy->dev, "%s: Start to mask iGo CMD\n", __func__);
    mutex_unlock(&debussy->igo_ch_lock);
}

static const struct snd_soc_dai_ops debussy_aif_dai_ops = {
    .hw_params = debussy_hw_params,
    .set_fmt = debussy_set_dai_fmt,
    .set_sysclk = debussy_set_dai_sysclk,
    .set_pll = debussy_set_dai_pll,
    .shutdown = debussy_shutdown,
};

static struct snd_soc_dai_driver debussy_dai[] = {
    {
        .name = "debussy-aif",
        .id = DEBUSSY_AIF,
        .playback = {
            .stream_name = "AIF Playback",
            .channels_min = 1,
            .channels_max = 2,
            .rates = DEBUSSY_RATES,
            .formats = DEBUSSY_FORMATS,
        },
        .capture = {
            .stream_name = "AIF Capture",
            .channels_min = 1,
            .channels_max = 2,
            .rates = DEBUSSY_RATES,
            .formats = DEBUSSY_FORMATS,
        },
        .ops = &debussy_aif_dai_ops,
    },
};
EXPORT_SYMBOL_GPL(debussy_dai);

///////////////////////////////////////////////////////////////////////
static void _debussy_hif_cali(struct debussy_priv* debussy)
{
    struct i2c_client* client;
    int32_t readStatus;
    int32_t testCount;
    uint32_t config, nTimeTest;
    struct timeval tvBegin, tvNow;
    uint32_t data;

    if (!debussy) {
        dev_err(debussy->dev, "%s: debussy is NULL\n", __func__);
        return;
    }

    client = i2c_verify_client(debussy->dev);

#if (DRIVER_COMMAND_VERSION >= 0x10020001)
    if (IGO_CH_STATUS_DONE == igo_ch_read(debussy->dev, IGO_CH_IGO_CMD_VER_ADDR, &data)) {
        uint8_t support_quick_cali = 1;

        dev_info(debussy->dev, "Driver: iGo CMD Version = %X.%X.%X\n",
            IGO_CMD_VER_GET(DRIVER_COMMAND_VERSION),
            IGO_MAJOR_VER_GET(DRIVER_COMMAND_VERSION),
            IGO_MINOR_VER_GET(DRIVER_COMMAND_VERSION));
        dev_info(debussy->dev, "FW: iGo CMD Version = %X.%X.%X\n",
            IGO_CMD_VER_GET(data),
            IGO_MAJOR_VER_GET(data),
            IGO_MINOR_VER_GET(data));

        if (0x10020001 > data) {
            // FW iGo CMD Version < 1.2.1, not support quick cali function
            support_quick_cali = 0;
        }

        if (support_quick_cali) {
            if (IGO_CH_STATUS_DONE != igo_ch_read(debussy->dev, IGO_CH_CALI_STATUS_ADDR, &data)) {
                if (0 == data) {
                    // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
                    debussy->mcu_hold(debussy->dev, 0);
                    debussy->reset_chip(debussy->dev, 1, 0);
                    dev_err(debussy->dev, "%s: Not need calibration\n", __func__);

                    return;
                }
            }

            // Initial 0x2a012088 to not ready
            igo_i2c_write(client, 0x2a012088, 1);

            if (IGO_CH_STATUS_DONE != igo_ch_write(debussy->dev, IGO_CH_HIF_CALI_EN_ADDR, HIF_CALI_EN_QCK_EN)) {
                // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
                debussy->mcu_hold(debussy->dev, 0);
                debussy->reset_chip(debussy->dev, 1, 0);
                dev_err(debussy->dev, "%s: Unable to enable HIF calibration mode\n", __func__);

                return;
            }

            readStatus = 150;

            while (--readStatus) {
                config = 0;
                igo_i2c_read(client, 0x2A012088, &config);

                if (0 == config) {
                    break;
                }

                usleep_range(4999, 5000);       // 5ms
            }

            if (0 >= readStatus) {
                dev_err(debussy->dev, "%s: config=%d: HIF calibration mode timeout.\n", __func__, config);
                // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
                debussy->mcu_hold(debussy->dev, 0);
                debussy->reset_chip(debussy->dev, 1, 0);

                return;
            }

            igo_i2c_write(client, 0x2A012098, 0);
            do_gettimeofday(&tvBegin);
            igo_i2c_write(client, 0x2A012088, 2);
            msleep(CLK_CALI_INTERVAL);
            igo_i2c_write(client, 0x2A012098, 0);
            do_gettimeofday(&tvNow);

            nTimeTest = (tvNow.tv_sec - tvBegin.tv_sec) * 1000000 + tvNow.tv_usec - tvBegin.tv_usec;
            igo_i2c_write(client, 0x2A012088, nTimeTest);
            dev_info(debussy->dev, "%s: nTimeTest = %d\n", __func__, nTimeTest);

            readStatus = 150;
            while (--readStatus) {
                config = 0;
                igo_i2c_read(client, 0x2A012088, &config);

                if (0xFFFFFFFF == config) {
                    break;
                }

                usleep_range(4999, 5000);       // 5ms
            }

            if (0xFFFFFFFF == config) {
                dev_info(debussy->dev, "%s: HIF calibration mode is complete.\n", __func__);
            }
            else {
                dev_err(debussy->dev, "%s: config=%d: HIF calibration mode timeout.\n", __func__, config);
            }

            // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
            debussy->mcu_hold(debussy->dev, 0);
            debussy->reset_chip(debussy->dev, 1, 0);

            return;
        }
    }
#endif

    // Initial 0x2a012088 to not ready
    igo_i2c_write(client, 0x2a012088, 1);

    if (IGO_CH_STATUS_DONE != igo_ch_write(debussy->dev, IGO_CH_HIF_CALI_EN_ADDR, HIF_CALI_EN_ENABLE)) {
        // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
        debussy->mcu_hold(debussy->dev, 0);
        debussy->reset_chip(debussy->dev, 1, 0);
        dev_err(debussy->dev, "%s: Unable to enable HIF calibration mode\n", __func__);

        return;
    }

    testCount = 1000;

    while (--testCount) {
        readStatus = 150;

        while (--readStatus) {
            config = 0;
            igo_i2c_read(client, 0x2A012088, &config);

            if (0 == config || 0xFFFFFFFF == config) {
                break;
            }

            usleep_range(4999, 5000);       // 5ms
        }

        igo_i2c_read(client, 0x2A000204, &data);
        dev_info(debussy->dev, "lvl 0x%08x\n", data);
        igo_i2c_read(client, 0x2A000208, &data);
        dev_info(debussy->dev, "taget %d\n", data);
        igo_i2c_read(client, 0x2A00020c, &data);
        dev_info(debussy->dev, "read %d\n", data);

        if (0xFFFFFFFF == config || 0 >= readStatus) {
            if (0 >= readStatus) {
                dev_info(debussy->dev, "%s: config=%d: HIF calibration mode timeout.\n", __func__, config);
                // igo_ch_write(debussy->dev, IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY);
                debussy->mcu_hold(debussy->dev, 0);
                debussy->reset_chip(debussy->dev, 1, 0);

                return;
            }

            dev_info(debussy->dev, "%s: HIF calibration mode done.\n", __func__);
            break;
        }

        igo_i2c_read(client, 0x2A012098, &config);
        do_gettimeofday(&tvBegin);
        msleep(100);
        igo_i2c_read(client, 0x2A012098, &config);
        do_gettimeofday(&tvNow);
        nTimeTest = (tvNow.tv_sec - tvBegin.tv_sec) * 1000000 + tvNow.tv_usec - tvBegin.tv_usec;
        igo_i2c_write(client, 0x2A012088, nTimeTest);
        dev_info(debussy->dev, "%s:%d - nTimeTest = %d\n", __func__, testCount, nTimeTest);
    }

    if (0 >= testCount) {
        dev_info(debussy->dev, "%s: HIF calibration mode timeout.\n", __func__);
    }

    debussy->mcu_hold(debussy->dev, 0);
    debussy->reset_chip(debussy->dev, 1, 0);
    dev_info(debussy->dev, "%s: HIF calibration mode is complete.\n", __func__);
}

static int _debussy_fw_update(struct debussy_priv *debussy, int force_update,
                              const unsigned char *fw_bin, unsigned int fw_size)
{
    const struct firmware *fw = NULL;
    char *fw_path = NULL;
    char *fw_name = "debussy.bin";
    int32_t ret, checkAgain = 0;
    uint32_t fw_ver = 0, data = 0;

    if (NULL == fw_bin) {
        fw_path = devm_kzalloc(debussy->dev, DEBUSSY_FW_NAME_SIZE, GFP_KERNEL);
        if (!fw_path) {
            dev_err(debussy->dev, "%s: Failed to allocate fw_path\n", __func__);

            return 0;
        }

        scnprintf(fw_path, DEBUSSY_FW_NAME_SIZE, "%s%s", DEBUSSY_FW_PATH, fw_name);
        dev_info(debussy->dev, "debussy fw name =%s", fw_path);

        ret = request_firmware(&fw, fw_path, debussy->dev);
        if (ret) {
            dev_err(debussy->dev, "%s: Failed to locate firmware %s errno = %d\n",
                    __func__, fw_path, ret);
            devm_kfree(debussy->dev, fw_path);

            return 2;
        }
    }

    mutex_lock(&debussy->igo_ch_lock);

#ifdef ENABLE_CODEC_DAPM_CB
    atomic_set(&debussy->referenceCount, 1);
#endif

    if (NULL == fw_bin) {
        dev_info(debussy->dev, "%s size = %d\n", fw_path, (uint32_t) fw->size);
        fw_ver = *(uint32_t *) &fw->data[DEBUSSY_FW_VER_OFFSET];
    }
    else {
        dev_info(debussy->dev, "FW size = %d\n", fw_size);
        fw_ver = *(uint32_t *) &fw_bin[DEBUSSY_FW_VER_OFFSET];
    }

    dev_info(debussy->dev, "BIN VER: 0x%08X\n", fw_ver);

#ifdef ENABLE_CODEC_DAPM_CB
    if (gpio_is_valid(debussy->reset_gpio)) {
        gpio_direction_output(debussy->reset_gpio, GPIO_HIGH);
        gpio_set_value(debussy->reset_gpio, GPIO_HIGH);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);
    }
#endif

    if (0 == force_update) {
        ret = igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &data);
        if (ret != IGO_CH_STATUS_DONE) {
            data = 0;
            dev_info(debussy->dev, "Can't get CHIP FW VER\n");
        }
        else {
			//set_debussy_version(data); //Eric.Hu add.
            dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", data);
        }
    }

    if ((fw_ver > data) || force_update) {
        debussy->mcu_hold(debussy->dev, 1);
        debussy->reset_chip(debussy->dev, 0, 0);
        debussy->mcu_hold(debussy->dev, 0);
        dev_info(debussy->dev, "Update FW to 0x%08x\n", fw_ver);
#ifdef DEBUSSY_TYPE_PSRAM
        if (NULL == fw_bin) {
            debussy_psram_update_firmware(debussy->dev,
                                          DEBUSSY_FW_ADDR,
                                          fw->data, fw->size);
        }
        else {
            debussy_psram_update_firmware(debussy->dev,
                                          DEBUSSY_FW_ADDR,
                                          (const u8 *) fw_bin, fw_size);
        }
#else
        if (NULL == fw_bin) {
            debussy_flash_update_firmware(debussy->dev,
                                        DEBUSSY_FW_ADDR,
                                        (const u8 *) fw->data, fw->size);
        }
        else {
            debussy_flash_update_firmware(debussy->dev,
                                        DEBUSSY_FW_ADDR,
                                        (const u8 *) fw_bin, fw_size);
        }
#endif
        checkAgain = 1;
    } else {
        dev_info(debussy->dev, "Use chip built-in FW\n");
    }

#ifdef ENABLE_REFERENCE_COUNT
    #ifdef ENABLE_CODEC_DAPM_CB
    atomic_set(&debussy->referenceCount, 0);
    #endif
#endif

    mutex_unlock(&debussy->igo_ch_lock);

    if (fw)
        release_firmware(fw);

    if (fw_path)
        devm_kfree(debussy->dev, fw_path);

    return checkAgain;
}

static void _debussy_manual_load_firmware(struct work_struct* work)
{
    struct debussy_priv* debussy;
    uint32_t fw_ver;

    debussy = container_of(work, struct debussy_priv, fw_work);
    _debussy_fw_update(debussy, 1, NULL, 0);

    mutex_lock(&debussy->igo_ch_lock);

    if (IGO_CH_STATUS_DONE == igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &fw_ver)) {
        // Calibration
		//set_debussy_version(fw_ver); //Eric.Hu add.
        dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", fw_ver);
        _debussy_hif_cali(debussy);
    }

    mutex_unlock(&debussy->igo_ch_lock);
    dev_info(debussy->dev, "%s: Done\n", __func__);
}

#ifndef IGO_DUMMY_DRIVER
static void _debussy_poweron_load_firmware(struct work_struct* work)
{
    struct debussy_priv* debussy = container_of(work, struct debussy_priv, poweron_update_fw_work.work);
    int32_t force_update = 0;
    uint32_t ver;

    #ifdef DEBUSSY_TYPE_PSRAM
    force_update = 1;
    #endif

   dev_info(debussy->dev, "%s - %d\n", __func__, force_update);

    if (1 == _debussy_fw_update(debussy, force_update, debussy_bin, sizeof(debussy_bin))) {
        _debussy_fw_update(debussy, 0, debussy_bin, sizeof(debussy_bin));
        mutex_lock(&debussy->igo_ch_lock);

        if (IGO_CH_STATUS_DONE == igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &ver)) {
            // Calibration
			//set_debussy_version(ver); //Eric.Hu add.
            dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", ver);
            _debussy_hif_cali(debussy);
        }

        mutex_unlock(&debussy->igo_ch_lock);
    }

    dev_info(debussy->dev, "%s: Done\n", __func__);
}
#endif

#ifdef IGO_STANDBY_INSTEAD_OF_DELAY_WORK
static void _debussy_standby_delaywork(struct work_struct* work)
{
    struct debussy_priv* debussy = container_of(work, struct debussy_priv, standby_work.work);

    igo_spi_intf_enable(1);
    dev_info(debussy->dev, "%s: Reset debussy chip done\n", __func__);
    mutex_unlock(&debussy->igo_ch_lock);
}
#endif

static int _debussy_codec_probe(struct snd_soc_codec* codec)
{
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(codec->dev));

    dev_info(codec->dev, "%s\n", __func__);
    debussy_add_codec_controls(codec);
    debussy->codec = codec;

#ifdef IGO_STANDBY_INSTEAD_OF_DELAY_WORK
    INIT_DELAYED_WORK(&debussy->standby_work, _debussy_standby_delaywork);
#endif

#ifdef IGO_DUMMY_DRIVER
    // NOP
#else
    if (debussy->request_fw_delaytime) {
        INIT_DELAYED_WORK(&debussy->poweron_update_fw_work, _debussy_poweron_load_firmware);
        schedule_delayed_work(&debussy->poweron_update_fw_work, debussy->request_fw_delaytime * HZ);
    }
    else {
        int force_update = 0;
        uint32_t fw_ver;

        #ifdef DEBUSSY_TYPE_PSRAM
        force_update = 1;
        #endif

        if (1 == _debussy_fw_update(debussy, force_update, debussy_bin, sizeof(debussy_bin))) {
            _debussy_fw_update(debussy, 0, debussy_bin, sizeof(debussy_bin));
            mutex_lock(&debussy->igo_ch_lock);

            if (IGO_CH_STATUS_DONE == igo_ch_read(debussy->dev, IGO_CH_FW_VER_ADDR, &fw_ver)) {
                // Calibration
				//set_debussy_version(fw_ver); //Eric.Hu add.
                dev_info(debussy->dev, "CHIP FW VER: 0x%08X\n", fw_ver);
                _debussy_hif_cali(debussy);
            }

            mutex_unlock(&debussy->igo_ch_lock);
        }
    }
#endif

    /////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_KWS
    {
        uint32_t enable_kws;

        if (of_property_read_u32(i2c_verify_client(debussy->dev)->dev.of_node, "ig,enable-kws", &enable_kws)) {
            dev_err(debussy->dev, "Unable to get \"ig,enable-kws\"\n");
            enable_kws = 0;
        }

        dev_info(debussy->dev, "ig,enable-kws = %d\n", enable_kws);

        if (enable_kws) {
            debussy_kws_init(debussy);
        }
    }
#endif

    pr_info("%s codec probe suscess\n", __func__);

    return 0;
}

static int _debussy_codec_remove(struct snd_soc_codec* codec)
{
    dev_info(codec->dev, "%s\n", __func__);

    return 0;
}

static int _debussy_codec_suspend(struct snd_soc_codec* codec)
{
#ifdef ENABLE_CODEC_DAPM_CB
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(codec->dev));

#ifdef ENABLE_REFERENCE_COUNT
    if (0 != atomic_read(&debussy->referenceCount))
        return 0;
#endif

    dev_info(codec->dev, "%s\n", __func__);

    if (gpio_is_valid(debussy->reset_gpio)) {
        gpio_direction_output(debussy->reset_gpio, GPIO_LOW);
        gpio_set_value(debussy->reset_gpio, GPIO_LOW);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);
    }
    else {
        dev_err(codec->dev, "%s: Reset GPIO-%d is invalid\n", __func__, debussy->reset_gpio);
    }
#endif

    return 0;
}

static int _debussy_codec_resume(struct snd_soc_codec* codec)
{
#ifdef ENABLE_CODEC_DAPM_CB
    struct debussy_priv* debussy = i2c_get_clientdata(i2c_verify_client(codec->dev));
    uint32_t tmp_data = 0;

    dev_info(codec->dev, "%s\n", __func__);

    debussy_power_enable(1);

    if (gpio_is_valid(debussy->reset_gpio)) {
        gpio_direction_output(debussy->reset_gpio, GPIO_HIGH);
        gpio_set_value(debussy->reset_gpio, GPIO_HIGH);
        usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);

        igo_i2c_write(i2c_verify_client(debussy->dev), 0x2A000018, tmp_data);
        msleep(debussy->reset_release_time);
        igo_spi_intf_enable(1);
    }
    else {
        dev_err(codec->dev, "%s: Reset GPIO-%d is invalid\n", __func__, debussy->reset_gpio);
    }
#endif

    return 0;
}

static struct snd_soc_codec_driver soc_codec_dev_debussy = {
    .probe = _debussy_codec_probe,
    .remove = _debussy_codec_remove,
    .suspend = _debussy_codec_suspend,
    .resume = _debussy_codec_resume,

};
EXPORT_SYMBOL_GPL(soc_codec_dev_debussy);

static int _debussy_debufs_init(struct debussy_priv* debussy)
{
    int ret = 0;
    struct dentry* dir = NULL;

    debussy->reg_address = 0x2A000000;

    dir = debugfs_create_dir("debussy", NULL);
    if (IS_ERR_OR_NULL(dir)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node - %s\n",
            __func__, "debussy");
        dir = NULL;
        ret = -ENODEV;
        goto err_create_dir;
    }

    debussy->dir = dir;

    if (!debugfs_create_file("download_firmware", S_IWUSR,
            dir, debussy, &debussy_download_firmware_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node - %s\n",
            __func__, "download_firmware");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("reset_chip", S_IWUSR,
            dir, debussy, &debussy_reset_chip_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node - %s\n",
            __func__, "reset_chip");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("reset_gpio_pull_down", S_IWUSR,
            dir, debussy, &debussy_reset_gpio_pull_down_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node - %s\n",
            __func__, "reset_gpio_pull_down");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("reset_gpio_pull_up", S_IWUSR,
            dir, debussy, &debussy_reset_gpio_pull_up_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node - %s\n",
            __func__, "reset_gpio_pull_up");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("mcu_hold", S_IWUSR,
            dir, debussy, &debussy_mcu_hold_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "mcu_hold");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("get_fw_version", S_IWUSR,
            dir, debussy, &debussy_get_fw_version_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "get_fw_version");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("debussy_reg", S_IWUSR,
            dir, debussy, &debussy_reg_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "debussy_reg");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("reg_get", S_IWUSR,
            dir, debussy, &debussy_reg_get_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "reg_get");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("reg_put", S_IWUSR,
            dir, debussy, &debussy_reg_put_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "reg_put");
        ret = -ENODEV;
        goto err_create_entry;
    }

    if (!debugfs_create_file("hif_cali", S_IWUSR,
            dir, debussy, &debussy_hif_calibration_fops)) {
        dev_err(debussy->dev, "%s: Failed to create debugfs node %s\n",
            __func__, "hif_cali");
        ret = -ENODEV;
        goto err_create_entry;
    }

err_create_dir:
    debugfs_remove(dir);

err_create_entry:
    return ret;
}

static void parser_dts_table(struct debussy_priv* debussy, struct i2c_client* i2c) {
    struct device_node *node = i2c->dev.of_node;

    debussy_dts_table_cus(debussy, node);       // power enable pin ctrl
    debussy_power_enable(1);

    /////////////////////////////////////////////////////////////////////////
    {
        char *dev_name = NULL;

        if (0 == of_property_read_string(node, "ig,device_name", (const char **) &dev_name)) {
            dev_info(debussy->dev, "ig,device_name = %s\n", dev_name);
            dev_set_name(debussy->dev, "%s", dev_name);
        }
    }

    /////////////////////////////////////////////////////////////////////////
    debussy->mcu_hold_gpio = of_get_named_gpio(node, "ig,mcu-hold-gpio", 0);
    if (debussy->mcu_hold_gpio < 0) {
        dev_err(debussy->dev, "Unable to get \"ig,mcu-hold-gpio\"\n");
    }
    else {
        dev_info(debussy->dev, "debussy->mcu_hold_gpio = %d\n", debussy->mcu_hold_gpio);

        if (gpio_is_valid(debussy->mcu_hold_gpio)) {
            if (0 == gpio_request(debussy->mcu_hold_gpio, "IGO_MCU_HOLD")) {
#ifdef DEBUSSY_TYPE_PSRAM
                gpio_direction_output(debussy->mcu_hold_gpio, GPIO_HIGH);
#else
                gpio_direction_output(debussy->mcu_hold_gpio, GPIO_LOW);
#endif
            }
            else {
                dev_err(debussy->dev, "IGO_MCU_HOLD: gpio_request fail\n");
            }
        }
        else {
            dev_err(debussy->dev, "debussy->mcu_hold_gpio is invalid\n");
        }
    }

    /////////////////////////////////////////////////////////////////////////
    if (of_property_read_u32(node, "ig,reset-hold-time", &debussy->reset_hold_time)) {
        dev_err(debussy->dev, "Unable to get \"ig,reset-hold-time\"\n");
        debussy->reset_hold_time = IGO_RST_HOLD_TIME_MIN;
    }
    else if (debussy->reset_hold_time < IGO_RST_HOLD_TIME_MIN) {
        debussy->reset_hold_time = IGO_RST_HOLD_TIME_MIN;
    }

    dev_info(debussy->dev, "debussy->reset_hold_time = %dms\n", debussy->reset_hold_time);

    if (of_property_read_u32(node, "ig,reset-release-time", &debussy->reset_release_time)) {
        dev_err(debussy->dev, "Unable to get \"ig,reset-release-time\"\n");
        debussy->reset_release_time = IGO_RST_RELEASE_TIME_MIN;
    }
    else if (debussy->reset_release_time < IGO_RST_RELEASE_TIME_MIN) {
        debussy->reset_release_time = IGO_RST_RELEASE_TIME_MIN;
    }

    dev_info(debussy->dev, "debussy->reset_release_time = %dms\n", debussy->reset_release_time);

    /////////////////////////////////////////////////////////////////////////
    debussy->reset_gpio = of_get_named_gpio(node, "ig,reset-gpio", 0);
    if (debussy->reset_gpio < 0) {
        dev_err(debussy->dev, "Unable to get \"ig,reset-gpio\"\n");
        debussy->reset_gpio = IGO_RST_GPIO;
    }
    else {
        dev_info(debussy->dev, "debussy->reset_gpio = %d\n", debussy->reset_gpio);
    }

    if (gpio_is_valid(debussy->reset_gpio)) {
        if (0 == gpio_request(debussy->reset_gpio, "IGO_RESET")) {
            gpio_direction_output(debussy->reset_gpio, GPIO_LOW);
            gpio_set_value(debussy->reset_gpio, GPIO_LOW);

            #ifdef DEBUSSY_TYPE_PSRAM
            debussy->reset_chip(debussy->dev, 0, 0);
            #else
            debussy->mcu_hold(debussy->dev, 0);
            debussy->reset_chip(debussy->dev, 1, 0);
            #endif
        }
        else {
            dev_err(debussy->dev, "IGO_RESET: gpio_request fail\n");
        }
    }
    else {
        dev_err(debussy->dev, "debussy->reset_gpio is invalid: %d\n", debussy->reset_gpio);
    }

    /////////////////////////////////////////////////////////////////////////
    if (of_property_read_u32(node, "ig,request_fw_delaytime", &debussy->request_fw_delaytime)) {
        dev_err(debussy->dev, "Unable to get \"ig,request_fw_delaytime\"\n");
        debussy->request_fw_delaytime = 0;      // default: Disable delay work method
    }

    /////////////////////////////////////////////////////////////////////////
    if (of_property_read_u32(node, "ig,max_data_length_i2c", &debussy->max_data_length_i2c)) {
        dev_err(debussy->dev, "Unable to get \"ig,max_data_length_i2c\"\n");
        debussy->max_data_length_i2c = DEFAULT_I2C_MAX_DATA_LEN;
    }
    else {
        dev_info(debussy->dev, "debussy->max_data_length_i2c = %d\n", debussy->max_data_length_i2c);
    }

    debussy->max_data_length_spi = DEFAULT_SPI_MAX_DATA_LEN;

    debussy->dma_mode_i2c = 0;
    debussy->dma_mode_spi = 0;
}

static int igo_i2c_probe(struct i2c_client *i2c,
    const struct i2c_device_id *id)
{
    struct debussy_priv *debussy;
    int ret;
    printk("%s - Version: %s\n", __func__, IGO_DRIVER_VERSION);
    printk("Linux Version = %d.%d.%d\n",
        (LINUX_VERSION_CODE >> 16) & 0xFF,
        (LINUX_VERSION_CODE >> 8) & 0xFF,
        (LINUX_VERSION_CODE) & 0xFF);

    debussy = devm_kzalloc(&i2c->dev, sizeof(struct debussy_priv), GFP_KERNEL);
    if (!debussy) {
        printk("Failed to allocate memory\n");
        return -ENOMEM;
    }

    {
        uint32_t t = 0x12345678;
        uint8_t *p = (uint8_t *) &t;

        if (*p == 0x78) {
            debussy->isLittleEndian = 1;
            printk("System is little endian\n");
        }
        else {
            debussy->isLittleEndian = 0;
            printk("System is big endian\n");
        }

        printk("[%s %d] %02X %02X %02X %02X\n", __func__,__LINE__, *p, *(p+1), *(p+2), *(p+3));
    }

    #ifdef ENABLE_DEBUSSY_I2C_REGMAP
    printk("Enable I2C regmap\n");
    debussy->i2c_regmap = devm_regmap_init_i2c(i2c, &debussy_i2c_regmap);
    if (IS_ERR(debussy->i2c_regmap)) {
        printk("Failed to allocate I2C regmap!\n");
        debussy->i2c_regmap = NULL;
    }
    else {
        regcache_cache_bypass(debussy->i2c_regmap, 1);
    }
    #endif

    p_debussy_priv = debussy;
    debussy->dev = &i2c->dev;
    atomic_set(&debussy->maskConfigCmd, 1);
#ifdef ENABLE_REFERENCE_COUNT
    atomic_set(&debussy->referenceCount, 0);
#else
    atomic_set(&debussy->referenceCount, 1);
#endif
    atomic_set(&debussy->kws_triggered, 0);
    atomic_set(&debussy->kws_count, 0);
    atomic_set(&debussy->vad_count, 0);

    debussy->reset_chip = _debussy_reset_chip_ctrl;
    debussy->mcu_hold = _debussy_mcu_hold_ctrl;
    i2c_set_clientdata(i2c, debussy);

    /////////////////////////////////////////////////////////////////////////
    parser_dts_table(debussy, i2c);

    /////////////////////////////////////////////////////////////////////////
    debussy->debussy_wq = create_singlethread_workqueue("debussy");
    if (debussy->debussy_wq == NULL) {
        dev_info(debussy->dev, "create singlethread workqueue fail\n");
        devm_kfree(debussy->dev, debussy);
        ret = -ENOMEM;
        goto out;
    }

    INIT_WORK(&debussy->fw_work, _debussy_manual_load_firmware);

    _debussy_debufs_init(debussy);

    mutex_init(&debussy->igo_ch_lock);

    dev_info(debussy->dev, "Register Codec\n");
    //snc_soc_register_codec  : 注册codec dai
    ret = snd_soc_register_codec(&i2c->dev, &soc_codec_dev_debussy, debussy_dai, ARRAY_SIZE(debussy_dai));

    {
        // Test only
        uint32_t data;

        dev_info(debussy->dev, "I2C Test ...\n");
        debussy->reset_chip(debussy->dev, 0, 0);

        igo_i2c_read(i2c, 0x2A000000, &data);
        dev_info(debussy->dev, "CHIP ID: 0x%08X\n", data);
    }

    /////////////////////////////////////////////////////////////////////////
#ifndef DEBUSSY_TYPE_PSRAM
    {
        uint32_t temp;
        int status;

        dev_info(debussy->dev, "Driver: iGo CMD Version = %d.%d.%d\n",
            IGO_CMD_VER_GET(DRIVER_COMMAND_VERSION),
            IGO_MAJOR_VER_GET(DRIVER_COMMAND_VERSION),
            IGO_MINOR_VER_GET(DRIVER_COMMAND_VERSION));

        mutex_lock(&debussy->igo_ch_lock);
        status = igo_ch_read(debussy->dev, IGO_CH_IGO_CMD_VER_ADDR, &temp);
        mutex_unlock(&debussy->igo_ch_lock);

        if (IGO_CH_STATUS_DONE == status) {
            dev_info(debussy->dev, "FW: iGo CMD Version = %d.%d.%d\n",
                IGO_CMD_VER_GET(temp),
                IGO_MAJOR_VER_GET(temp),
                IGO_MINOR_VER_GET(temp));

            if (IGO_CMD_VER_GET(temp) != IGO_CMD_VER_GET(DRIVER_COMMAND_VERSION)) {
                dev_err(debussy->dev, "Driver Version is not compatible with FW version !!!!\n");
            }
            else if (IGO_MAJOR_VER_GET(temp) != IGO_MAJOR_VER_GET(DRIVER_COMMAND_VERSION)) {
                dev_err(debussy->dev, "Driver Major Version does not match / compatible FW version !!!!\n");
            }
            else if (IGO_MINOR_VER_GET(temp) != IGO_MINOR_VER_GET(DRIVER_COMMAND_VERSION)) {
                dev_err(debussy->dev, "Driver Minor Version does not match / compatible FW version !!!!\n");
            }
        }
        else {
            // Old FW Version
            dev_err(debussy->dev, "Driver Version is not compatible with FW version !!!!\n");
        }
    }
#endif

    igo_spi_intf_init();

    #ifdef ENABLE_CDEV
    debussy_cdev_init(debussy);
    #endif

out:
    dev_info(debussy->dev, "End of igo_i2c_probe\n");

    return ret;
}

static int igo_i2c_remove(struct i2c_client* i2c)
{
    #ifdef ENABLE_DEBUSSY_I2C_REGMAP
    if (p_debussy_priv->i2c_regmap) {
        regmap_exit(p_debussy_priv->i2c_regmap);
    }
    #endif

    if (gpio_is_valid(p_debussy_priv->reset_gpio)) {
        gpio_free(p_debussy_priv->reset_gpio);
    }

    if (gpio_is_valid(p_debussy_priv->mcu_hold_gpio)) {
        gpio_free(p_debussy_priv->mcu_hold_gpio);
    }

    devm_kfree(&i2c->dev, p_debussy_priv);
    p_debussy_priv = NULL;

    igo_spi_intf_exit();

    #ifdef ENABLE_GENETLINK
    debussy_genetlink_exit();
    #endif
    #ifdef ENABLE_CDEV
    debussy_cdev_exit();
    #endif
    snd_soc_unregister_codec(&i2c->dev);

    return 0;
}

static struct i2c_driver igo_i2c_driver = {
    .driver = {
        .name = "debussy",
        .owner = THIS_MODULE,
        .of_match_table = of_match_ptr(debussy_of_match),
    },
    .probe = igo_i2c_probe,
    .remove = igo_i2c_remove,
    .id_table = igo_i2c_id,
};

#ifdef module_i2c_driver
module_i2c_driver(igo_i2c_driver);
#else
static int __init igo_driver_init(void)
{
    return i2c_register_driver(&igo_i2c_driver);
}
module_init(igo_driver_init);

static void __exit igo_driver_exit(void)
{
    return i2c_del_driver(&igo_i2c_driver);
}
module_exit(igo_driver_exit);
#endif

MODULE_DESCRIPTION("Debussy driver");
MODULE_LICENSE("GPL v2");
