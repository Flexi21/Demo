#ifndef DEBUSSY_SCENARIOS_H
#define DEBUSSY_SCENARIOS_H

#include <linux/version.h>
#include "debussy_snd_ctrl.h"

#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,13,11)
// For Android 5.1
#define snd_soc_kcontrol_codec          snd_kcontrol_chip
#endif

#define IGO_CH_WAIT_ADDR            (0xFFFFFFFF)

/////////////////////////////////////////////////////////////////////////
enum scenarios_sel{
    SCENARIOS_SEL_STANDBY = 0,
    SCENARIOS_SEL_HANDSET_0 = 1,
    SCENARIOS_SEL_HANDSET_1 = 2,
    SCENARIOS_SEL_HANDSET_2 = 3,
    SCENARIOS_SEL_HANDFREE_0 = 4,
    SCENARIOS_SEL_HANDFREE_1 = 5,
    SCENARIOS_SEL_HANDFREE_2 = 6,
    SCENARIOS_SEL_HEADSET_0 = 7,
    SCENARIOS_SEL_HEADSET_1 = 8,
    SCENARIOS_SEL_HEADSET_2 = 9,
    SCENARIOS_SEL_VOICE_REC_0 = 10,
    SCENARIOS_SEL_VOICE_REC_1 = 11,
    SCENARIOS_SEL_VOICE_REC_2 = 12,
    SCENARIOS_SEL_VIDEO_REC_0 = 13,
    SCENARIOS_SEL_VIDEO_REC_1 = 14,
    SCENARIOS_SEL_VIDEO_REC_2 = 15,
    SCENARIOS_SEL_ASR_0 = 16,
    SCENARIOS_SEL_ASR_1 = 17,
    SCENARIOS_SEL_ASR_2 = 18,
    SCENARIOS_SEL_BYPASS_0 = 19,
    SCENARIOS_SEL_BYPASS_1 = 20,
    SCENARIOS_SEL_BYPASS_2 = 21,
    SCENARIOS_SEL_RESERVED_0 = 22,
    SCENARIOS_SEL_RESERVED_1 = 23,
    SCENARIOS_SEL_RESERVED_2 = 24,
};

typedef struct ST_IGO_DEBUSSY_CFG {
    uint32_t    cmd_addr;
    uint32_t    cmd_data;
} st_igo_scenarios_cfg_table;

#ifdef DEBUSSY_SCENARIOS_C

#define POWER_MODE_DELAY        (40)

struct ST_IGO_DEBUSSY_CFG dummy_cfg[] = {
    {IGO_CH_WAIT_ADDR, 0xFFFFFFFF}
};

struct ST_IGO_DEBUSSY_CFG standby_cfg[] = {
    {IGO_CH_POWER_MODE_ADDR, POWER_MODE_STANDBY},
    {IGO_CH_WAIT_ADDR, POWER_MODE_DELAY},
    {IGO_CH_WAIT_ADDR, 0xFFFFFFFF}
};

struct ST_IGO_DEBUSSY_CFG handset_nr_aec_cfg[] = {
    // keep at first
    {IGO_CH_POWER_MODE_ADDR, POWER_MODE_WORKING},
    {IGO_CH_WAIT_ADDR, POWER_MODE_DELAY},

    {IGO_CH_MCLK_ADDR, 19200000},
    {IGO_CH_DMIC_M_CLK_SRC_ADDR, DMIC_M_CLK_SRC_MCLK},
    {IGO_CH_DMIC_M0_P_MODE_ADDR, DMIC_M0_P_MODE_ENABLE},
    {IGO_CH_DMIC_M_BCLK_ADDR, 1200000},

    {IGO_CH_DAI_0_CLK_ADDR, DAI_0_CLK_16K},
    {IGO_CH_DAI_0_MODE_ADDR, DAI_0_MODE_SLAVE},
    {IGO_CH_DAI_0_DATA_BIT_ADDR, DAI_0_DATA_BIT_16},

    {IGO_CH_CH1_RX_ADDR, CH1_RX_DMIC_M0_P},
    {IGO_CH_CH1_TX_ADDR, CH1_TX_DAI0_TX_L},

    {IGO_CH_CH1_FLOOR_ADDR, CH1_FLOOR_LVL_2},
    {IGO_CH_CH1_OD_ADDR, CH1_OD_LVL_0},
    {IGO_CH_CH1_OD_ADDR, CH1_THR_LVL_0},

    {IGO_CH_NR_CH1_ADDR, NR_CH1_ENABLE},

    {IGO_CH_AEC_ADDR, AEC_ENABLE},
    {IGO_CH_AEC_REF_RX_ADDR, AEC_REF_RX_DAI0_RX_L},
    {IGO_CH_CH0_RX_ADDR, CH0_RX_DAI0_RX_L},

    // keep at last
    {IGO_CH_OP_MODE_ADDR, OP_MODE_NR},
    {IGO_CH_WAIT_ADDR, 0xFFFFFFFF}
};

struct ST_IGO_DEBUSSY_CFG handfree_nr_aec_cfg[] = {
    // keep at first
    {IGO_CH_POWER_MODE_ADDR, POWER_MODE_WORKING},
    {IGO_CH_WAIT_ADDR, POWER_MODE_DELAY},

    {IGO_CH_MCLK_ADDR, 19200000},
    {IGO_CH_DMIC_M_CLK_SRC_ADDR, DMIC_M_CLK_SRC_MCLK},
    {IGO_CH_DMIC_M1_P_MODE_ADDR, DMIC_M1_P_MODE_ENABLE},
    {IGO_CH_DMIC_M_BCLK_ADDR, 1200000},

    {IGO_CH_DAI_0_CLK_ADDR, DAI_0_CLK_48K},
    {IGO_CH_DAI_0_MODE_ADDR, DAI_0_MODE_SLAVE},
    {IGO_CH_DAI_0_DATA_BIT_ADDR, DAI_0_DATA_BIT_16},

    {IGO_CH_CH1_RX_ADDR, CH1_RX_DMIC_M1_P},
    {IGO_CH_CH1_TX_ADDR, CH1_TX_DAI0_TX_L},

    {IGO_CH_CH1_FLOOR_ADDR, CH1_FLOOR_LVL_2},
    {IGO_CH_CH1_OD_ADDR, CH1_OD_LVL_0},
    {IGO_CH_CH1_OD_ADDR, CH1_THR_LVL_0},

    {IGO_CH_NR_CH1_ADDR, NR_CH1_ENABLE},

    {IGO_CH_AEC_ADDR, AEC_ENABLE},
    {IGO_CH_AEC_REF_RX_ADDR, AEC_REF_RX_DAI0_RX_L},
    {IGO_CH_CH0_RX_ADDR, CH0_RX_DAI0_RX_L},

    // keep at last
    {IGO_CH_OP_MODE_ADDR, OP_MODE_NR},
    {IGO_CH_WAIT_ADDR, 0xFFFFFFFF}
};

struct ST_IGO_DEBUSSY_CFG headset_nr_aec_cfg[] = {
    // keep at first
    {IGO_CH_POWER_MODE_ADDR, POWER_MODE_WORKING},
    {IGO_CH_WAIT_ADDR, POWER_MODE_DELAY},

    {IGO_CH_DAI_0_CLK_ADDR, DAI_0_CLK_48K},
    {IGO_CH_DAI_0_MODE_ADDR, DAI_0_MODE_SLAVE},
    {IGO_CH_DAI_0_DATA_BIT_ADDR, DAI_0_DATA_BIT_16},

    {IGO_CH_CH1_RX_ADDR, CH1_RX_DAI0_RX_L},
    {IGO_CH_CH1_TX_ADDR, CH1_TX_DAI0_TX_L},

    {IGO_CH_CH1_FLOOR_ADDR, CH1_FLOOR_LVL_2},
    {IGO_CH_CH1_OD_ADDR, CH1_OD_LVL_0},
    {IGO_CH_CH1_OD_ADDR, CH1_THR_LVL_0},

    {IGO_CH_NR_CH1_ADDR, NR_CH1_ENABLE},

    // keep at last
    {IGO_CH_OP_MODE_ADDR, OP_MODE_NR},
    {IGO_CH_WAIT_ADDR, 0xFFFFFFFF}
};

// The table size is the same as the maximum ENUM of scenarios_sel.
struct ST_IGO_DEBUSSY_CFG *scenarios_mode_table[] = {
    &standby_cfg[0],                    // STANDBY_MODE
    // SCENARIOS_SEL_HANDSET
    &handset_nr_aec_cfg[0],
    &handset_nr_aec_cfg[0],
    &handset_nr_aec_cfg[0],
    // SCENARIOS_SEL_HANDFREE
    &handfree_nr_aec_cfg[0],
    &handfree_nr_aec_cfg[0],
    &handfree_nr_aec_cfg[0],
    // SCENARIOS_SEL_HEADSET
    &headset_nr_aec_cfg[0],
    &headset_nr_aec_cfg[0],
    &headset_nr_aec_cfg[0],
    // SCENARIOS_SEL_VOICE_REC
    &dummy_cfg[0],
    &dummy_cfg[0],
    &dummy_cfg[0],
    // SCENARIOS_SEL_VIDEO_REC
    &dummy_cfg[0],
    &dummy_cfg[0],
    &dummy_cfg[0],
    // SCENARIOS_SEL_ASR
    &dummy_cfg[0],
    &dummy_cfg[0],
    &dummy_cfg[0],
    // SCENARIOS_SEL_BYPASS
    &dummy_cfg[0],
    &dummy_cfg[0],
    &dummy_cfg[0],
    // SCENARIOS_SEL_RESERVED
    &dummy_cfg[0],
    &dummy_cfg[0],
    &dummy_cfg[0],
};

//////////////////////////////////////////////////////////////////////////
static const char* const enum_scenarios_sel[] = {
    "SCENARIOS_SEL_STANDBY",
    "SCENARIOS_SEL_HANDSET_0",
    "SCENARIOS_SEL_HANDSET_1",
    "SCENARIOS_SEL_HANDSET_2",
    "SCENARIOS_SEL_HANDFREE_0",
    "SCENARIOS_SEL_HANDFREE_1",
    "SCENARIOS_SEL_HANDFREE_2",
    "SCENARIOS_SEL_HEADSET_0",
    "SCENARIOS_SEL_HEADSET_1",
    "SCENARIOS_SEL_HEADSET_2",
    "SCENARIOS_SEL_VOICE_REC_0",
    "SCENARIOS_SEL_VOICE_REC_1",
    "SCENARIOS_SEL_VOICE_REC_2",
    "SCENARIOS_SEL_VIDEO_REC_0",
    "SCENARIOS_SEL_VIDEO_REC_1",
    "SCENARIOS_SEL_VIDEO_REC_2",
    "SCENARIOS_SEL_ASR_0",
    "SCENARIOS_SEL_ASR_1",
    "SCENARIOS_SEL_ASR_2",
    "SCENARIOS_SEL_BYPASS_0",
    "SCENARIOS_SEL_BYPASS_1",
    "SCENARIOS_SEL_BYPASS_2",
    "SCENARIOS_SEL_RESERVED_0",
    "SCENARIOS_SEL_RESERVED_1",
    "SCENARIOS_SEL_RESERVED_2",
};
static SOC_ENUM_SINGLE_EXT_DECL(soc_enum_scenarios_sel, enum_scenarios_sel);

/////////////////////////////////////////////////////////////////////////
static int igo_ch_scenarios_sel_get(struct snd_kcontrol* kcontrol,
    struct snd_ctl_elem_value* ucontrol)
{
    ucontrol->value.integer.value[0] = SCENARIOS_SEL_STANDBY;

    return 0;
}

static int igo_ch_scenarios_sel_put(struct snd_kcontrol* kcontrol,
    struct snd_ctl_elem_value* ucontrol)
{
    struct snd_soc_codec* codec = snd_soc_kcontrol_codec(kcontrol);
    int status = IGO_CH_STATUS_DONE;
    int index;
    struct ST_IGO_DEBUSSY_CFG *pst_scenarios_tab;
    struct debussy_priv* debussy = dev_get_drvdata(codec->dev);

    mutex_lock(&debussy->igo_ch_lock);

    pst_scenarios_tab = (struct ST_IGO_DEBUSSY_CFG *) scenarios_mode_table[ucontrol->value.integer.value[0]];

    index = 0;
    while (1) {
        if ((IGO_CH_WAIT_ADDR == (pst_scenarios_tab + index)->cmd_addr) &&
            (0xFFFFFFFF == (pst_scenarios_tab + index)->cmd_data)) {
            dev_info(codec->dev, "Wrong delay time\n");
            break;
        }

        if ((IGO_CH_WAIT_ADDR == (pst_scenarios_tab + index)->cmd_addr) &&
            (0xFFFFFFFF > (pst_scenarios_tab + index)->cmd_data)) {

            if ((pst_scenarios_tab + index)->cmd_data < 20) {
                usleep_range((pst_scenarios_tab + index)->cmd_data * 1000 - 1,
                             (pst_scenarios_tab + index)->cmd_data * 1000);
            }
            else {
                msleep((pst_scenarios_tab + index)->cmd_data);
            }
        }
        else {
            status = igo_ch_write(codec->dev, (unsigned int) (pst_scenarios_tab + index)->cmd_addr, (unsigned int) (pst_scenarios_tab + index)->cmd_data);
        }

        index++;
    }

    mutex_unlock(&debussy->igo_ch_lock);

    return 0;
}

#else

extern struct ST_IGO_DEBUSSY_CFG *scenarios_mode_table[];

#endif

#endif
