#include <linux/version.h>
#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/device.h>
#include <linux/delay.h>
#include <linux/i2c.h>
#include <linux/regmap.h>

#include "debussy.h"
#include "debussy_intf.h"

int igo_i2c_read_buffer(struct i2c_client *client,
                        unsigned int addr, unsigned int *buff,
                        unsigned int word_len)
{
	int retry=5;
#ifdef IGO_DUMMY_DRIVER
    memset_u32(buff, 0, word_len);
#else
    struct debussy_priv* debussy = i2c_get_clientdata(client);
    uint32_t *input_data = NULL;
    uint8_t buf[4];
    struct i2c_msg xfer[2];
    int32_t ret;

    if (!buff || !word_len)
        return -EFAULT;

    memset_u32((uint32_t *) buff, 0, word_len);

#ifdef ENABLE_DEBUSSY_I2C_REGMAP
    if (debussy->i2c_regmap) {
        return regmap_raw_read(debussy->i2c_regmap, addr, buff, word_len << 2);
    }
#endif

    buf[0] = (uint8_t) (addr >> 24);
    buf[1] = (uint8_t) (addr >> 16);
    buf[2] = (uint8_t) (addr >> 8);
    buf[3] = (uint8_t) (addr & 0xff);

    memset(xfer, 0, sizeof(xfer));

    xfer[0].addr = client->addr;
    xfer[0].flags = 0;
    xfer[0].len = 4;
    xfer[0].buf = buf;

    xfer[1].addr = client->addr;
    xfer[1].flags = I2C_M_RD;
    xfer[1].len = word_len << 2;

    if (debussy->isLittleEndian) {
        xfer[1].buf = (u8 *) buff;
    }
    else {
        input_data = (uint32_t *) devm_kzalloc(debussy->dev, word_len << 2, GFP_KERNEL);

        if (NULL == input_data) {
            dev_err(debussy->dev, "%s: alloc fail\n", __func__);
            return -EFAULT;
        }

        xfer[1].buf = (u8 *) input_data;
    }
	
	while(retry>0)
	{
		ret = i2c_transfer(client->adapter, xfer, 2);
		if(ret >0)
			break;
		printk("Eric.Hu debussy igo_i2c_read_buffer addr=0x%x len=%d ret=%d retry=%d\n",addr,word_len,ret,retry);
		retry--;
		usleep_range(1999+(5-retry)*1000, 2000+(5-retry)*1000);//Eric.Hu add.
	}
	
//	msleep(10);

    if (ret < 0) {
        pr_err("debussy: %s - i2c_transfer error => %d, Reg = 0x%X\n", __func__, ret, addr);

        if (input_data) {
            devm_kfree(&client->dev, input_data);
        }

        return ret;
    }
    else if (ret != 2) {
        pr_err("debussy: %s - i2c_transfer error => -EIO, Reg = 0x%X\n", __func__, addr);

        if (input_data) {
            devm_kfree(&client->dev, input_data);
        }

        return -EIO;
    }

    if (input_data) {
        if (0 == debussy->isLittleEndian) {
            endian_swap(buff, input_data, word_len);
        }

        devm_kfree(&client->dev, input_data);
    }
#endif

    return 0;
}

int igo_i2c_read(struct i2c_client *client,
                 unsigned int addr,
                 unsigned int *value)
{
    return igo_i2c_read_buffer(client, addr, value, 1);
}

int igo_i2c_write(struct i2c_client *client,
                  unsigned int addr, unsigned int value)
{
    return igo_i2c_write_buffer(client, addr, &value, 1);
}

int igo_i2c_write_buffer(struct i2c_client *client,
                        unsigned int addr, unsigned int *buff,
                        unsigned int word_len)
{
	int retry = 5;
#ifdef IGO_DUMMY_DRIVER
    // NOP
#else
    struct debussy_priv *debussy = i2c_get_clientdata(client);
    uint8_t *buf;
    struct i2c_msg xfer[1];
    int32_t ret;

    if (!buff || !word_len)
        return -EFAULT;
#ifdef ENABLE_DEBUSSY_I2C_REGMAP
    if (debussy->i2c_regmap) {
		ret = regmap_raw_write(debussy->i2c_regmap, addr, buff, word_len << 2);
		printk("Eric.Hu debussy I2C regmap igo_i2c_write_buffer addr=0x%x len=%d ret=%d \n",addr,word_len,ret);
//		msleep(10);
        return ret;
    }
#endif

    buf = (uint8_t *) devm_kzalloc(&client->dev, (word_len << 2) + 4, GFP_KERNEL);

    if (NULL == buf) {
        pr_err("debussy: %s: alloc fail\n", __func__);
        return -EFAULT;
    }

    buf[0] = (uint8_t) (addr >> 24) | 0x20;
    buf[1] = (uint8_t) (addr >> 16);
    buf[2] = (uint8_t) (addr >> 8);
    buf[3] = (uint8_t) (addr & 0xFF);

    if (debussy->isLittleEndian) {
        memcpy_u32((uint32_t *) &buf[4], buff, word_len);
    }
    else {
        endian_swap((uint32_t *) &buf[4], buff, word_len);
    }

    memset(xfer, 0, sizeof(xfer));

    xfer[0].addr = client->addr;
    xfer[0].flags = 0;
    xfer[0].len = 4 + (word_len << 2);
    xfer[0].buf = (u8 *) buf;

	while(retry>0)
	{
		ret = i2c_transfer(client->adapter, xfer, 1);
		if(ret >0)
			break;
		printk("Eric.Hu debussy igo_i2c_write_buffer ADDR=0x%x VAL=0x%x len=%d ret=%d retry=%d\n",addr,buff[0],word_len,ret,retry);
		usleep_range(1999+(5-retry)*1000, 2000+(5-retry)*1000);//Eric.Hu add.	//usleep_range(1999, 2000);//Eric.Hu add.
		retry--;
	}
	
    devm_kfree(&client->dev, buf);
	
    if (ret < 0) {
        pr_err("debussy: %s - i2c_transfer error => %d, Reg = 0x%X\n", __func__, ret, addr);
        return ret;
    }
    else if (ret != 1) {
        pr_err("debussy: %s - i2c_transfer error => -EIO, Reg = 0x%X\n", __func__, addr);
        return -EIO;
    }
#endif

    return 0;
}
