#include <linux/version.h>
#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/err.h>
#include <linux/list.h>
#include <linux/errno.h>
#include <linux/mutex.h>
#include <linux/compat.h>
#include <linux/spi/spi.h>
#include <linux/spi/spidev.h>

#include "debussy_intf.h"
#include "debussy.h"
#ifdef ENABLE_SPI_INTF
#include "debussy_spidev.h"
#endif

int igo_spi_read_buffer(unsigned int addr, unsigned int *buff, unsigned int word_len)
{
#if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    int ret = 0;

    if (!buff || !word_len)
        return -EFAULT;

    memset((void *) buff, 0, word_len << 2);
    ret = debussy_spidrv_buffer_read(addr, buff, word_len);

    if (ret)
        return 0;

    return ret;
#else
    return 1;
#endif
}

int igo_spi_read(unsigned int addr, unsigned int *value)
{
#if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    int ret;

    if (!value)
        return -EFAULT;

    *value = 0;
    ret = debussy_spidrv_reg_read(addr, value);

    if (ret)
        return 0;

    return ret;
#else
    return 1;
#endif
}

int igo_spi_write(unsigned int addr, unsigned int value) {
    return igo_spi_write_buffer(addr, &value, 1);
}

int igo_spi_write_buffer(unsigned int addr, unsigned int *buff, unsigned int word_len)
{
#if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    ssize_t ret;

    if (!buff)
        return -EFAULT;

    ret = debussy_spidrv_buffer_write(addr, buff, word_len);

    if (ret)
        return 0;

    return ret;
#else
    return 1;
#endif
}

int igo_spi_intf_enable(uint32_t enable) {
    #ifdef ENABLE_SPI_INTF
    return debussy_spidrv_intf_enable(enable);
    #else
    return 1;
    #endif
}

int igo_spi_intf_check(void) {
    #if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    return debussy_spidrv_intf_check();
    #else
    return 1;
    #endif
}

void igo_spi_intf_init(void) {
    #if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    debussy_spidev_init();
    #endif
}

void igo_spi_intf_exit(void) {
    #if (defined(ENABLE_SPI_INTF) && !defined(IGO_DUMMY_DRIVER))
    debussy_spidev_exit();
    #endif
}
