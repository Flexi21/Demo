#ifndef DEBUSSY_H
#define DEBUSSY_H

#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/firmware.h>
#include <linux/gpio.h>
#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/pm.h>
#include <linux/string.h>
#include <sound/core.h>
#include <sound/initval.h>
#include <sound/soc.h>
#include <sound/tlv.h>
#include <linux/regmap.h>
#include <linux/ioctl.h>

// #define IGO_DUMMY_DRIVER
#define IGO_DRIVER_VERSION              "v1.0.6 190506"
#define IGO_DRIVER_CMID                 "e25e091e2f2d6f561995675c3720c5114e4518ac"

#define IGO_RST_GPIO                    (-2)
#define IGO_KWS_INT                     (-2)

//#define ENABLE_KWS
//#define ENABLE_GENETLINK
//#define ENABLE_CDEV
//#define ENABLE_SPI_INTF
//#define DEBUSSY_TYPE_PSRAM              // else Flash type

#ifdef CONFIG_REGMAP_I2C
//#define ENABLE_DEBUSSY_I2C_REGMAP
#endif

#ifdef CONFIG_REGMAP_SPI
//#define ENABLE_DEBUSSY_SPI_REGMAP       // TBD
#endif

//#define IG_CH_CMD_USING_SPI             // TBD
//#define IGO_STANDBY_INSTEAD_OF_DELAY_WORK

#define IGO_RST_HOLD_TIME_MIN           (10)	//(3)         // ms
#define IGO_RST_RELEASE_INIT_TIME       (5000)	//(1000)      // us
#define IGO_RST_RELEASE_TIME_MIN        (200)	//(6)         // ms
#define DEFAULT_I2C_MAX_DATA_LEN        (256)       // bytes
#define DEFAULT_SPI_MAX_DATA_LEN        (256)       // bytes

#ifndef GPIO_LOW
#define GPIO_LOW        0
#endif

#ifndef GPIO_HIGH
#define GPIO_HIGH       1
#endif

#define IGO_CH_ACTION_OFFSET (28)

#define IGO_CH_RSV_ADDR     (0x2A0C7EF0)
#define IGO_CH_OPT_ADDR     (IGO_CH_RSV_ADDR + 0x04)
#define IGO_CH_STATUS_ADDR  (IGO_CH_RSV_ADDR + 0x08)
#define IGO_CH_CMD_ADDR     (IGO_CH_RSV_ADDR + 0x0C)
#define IGO_CH_BUF_ADDR     (IGO_CH_RSV_ADDR + 0x10)

#define IGO_CMD_VER_GET(ver)        ((ver >> 28) & 0x000F)
#define IGO_MAJOR_VER_GET(ver)      ((ver >> 16) & 0x0FFF)
#define IGO_MINOR_VER_GET(ver)      ((ver)       & 0xFFFF)

struct debussy_priv {
    struct regmap *i2c_regmap;
    struct device* dev;
    struct device* spi_dev;
    uint32_t max_data_length_i2c;
    uint32_t max_data_length_spi;
    uint8_t dma_mode_i2c;
    uint8_t dma_mode_spi;
    uint8_t isLittleEndian;
    uint8_t reserved;
    struct snd_soc_codec* codec;

    struct workqueue_struct* debussy_wq;
    struct work_struct fw_work;
    struct work_struct irq_work;
#ifdef IGO_STANDBY_INSTEAD_OF_DELAY_WORK
    struct delayed_work standby_work;
#endif
    struct delayed_work poweron_update_fw_work;
    unsigned int request_fw_delaytime;

    struct dentry* dir;
    struct mutex igo_ch_lock;
    atomic_t maskConfigCmd;
    atomic_t referenceCount;
    atomic_t kws_triggered;
    atomic_t kws_count;
    atomic_t vad_count;

    void (*reset_chip)(struct device *, uint8_t, uint8_t);
    void (*mcu_hold)(struct device *, uint32_t);

    uint32_t reg_address;
    int32_t reset_gpio;
    uint32_t reset_hold_time;           // Reset Active Time
    uint32_t reset_release_time;        // Waiting time after reset released
    int32_t mcu_hold_gpio;
};

enum {
    DEBUSSY_AIF,
};

struct ig_ioctl_rg_arg {
    uint32_t address;
    uint32_t data;
};

struct ig_ioctl_kws_arg {
    uint32_t count;
    uint32_t status;
};

struct ig_ioctl_enroll_model_arg {
    uint32_t byte_len;
    uint32_t buf_addr;
};

#define IOCTL_ID                    '\x66'
#define IOCTL_REG_SET               _IOW(IOCTL_ID, 0, struct ig_ioctl_rg_arg)
#define IOCTL_REG_GET               _IOR(IOCTL_ID, 1, struct ig_ioctl_rg_arg)
#define IOCTL_KWS_STATUS_CLEAR      _IO(IOCTL_ID, 2)
#define IOCTL_KWS_STATUS_GET        _IOR(IOCTL_ID, 3, struct ig_ioctl_kws_arg)
#define IOCTL_ENROLL_MOD_GET        _IOR(IOCTL_ID, 4, struct ig_ioctl_enroll_model_arg)
#define IOCTL_ENROLL_MOD_SET        _IOW(IOCTL_ID, 5, struct ig_ioctl_enroll_model_arg)

extern struct debussy_priv* p_debussy_priv;

extern int debussy_cdev_init(void *priv_data);
extern void debussy_cdev_exit(void);

extern void debussy_flash_update_firmware(struct device* dev, unsigned int faddr, const u8* data, size_t size);
extern void debussy_psram_update_firmware(struct device* dev, unsigned int faddr, const u8* data, size_t size);

extern void memcpy_u32(uint32_t *target, uint32_t *src, uint32_t word_len);
extern void memset_u32(uint32_t *target, uint32_t data, uint32_t word_len);
extern void endian_swap(uint32_t *target, uint32_t *source, uint32_t word_len);

#endif
