#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/i2c.h>
#include <linux/jiffies.h>

#include "debussy_intf.h"
#include "debussy.h"
#include "debussy_snd_ctrl.h"

#define IGO_TIMEOUT_TICKS (2 * HZ)      // 1 ~ 2sec
//#define IGO_TIMEOUT_RESET_CHIP          // Reset iGo chip while iGo CMD timeout occured
//#define ENABLE_MASK_CONFIG_CMD
//#define ENABLE_CMD_BATCH_MODE_BUFFERED
//#define ENABLE_REFERENCE_COUNT

#define HW_RESET_INSTEAD_OF_STANDBY

#ifdef ENABLE_CMD_BATCH_MODE_BUFFERED
#define MAX_BATCH_MODE_CMD_NUM          (32)
static atomic_t batchMode = ATOMIC_INIT(0);
static atomic_t batchCmdNum = ATOMIC_INIT(0);
static uint32_t batch_cmd_buffer[64];
#endif

int igo_ch_chk_done(struct device *dev)
{
#ifdef IGO_DUMMY_DRIVER
    return IGO_CH_STATUS_DONE;
#else
    struct i2c_client* client;
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    unsigned long end_time = jiffies + IGO_TIMEOUT_TICKS;
    int32_t retval = 0;

    client = i2c_verify_client(dev);

    while (status == IGO_CH_STATUS_NOP || status == IGO_CH_STATUS_BUSY || status == IGO_CH_STATUS_CMD_RDY || status > IGO_CH_STATUS_MAX) {
#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            retval = igo_spi_read(IGO_CH_STATUS_ADDR, &status);
            if (0 != retval) {
                igo_spi_intf_enable(1);
                retval = igo_spi_read(IGO_CH_STATUS_ADDR, &status);
            }
        }
        else
#endif
        {
            retval = igo_i2c_read(client, IGO_CH_STATUS_ADDR, &status);
        }

        if (0 != retval) {
            dev_err(dev, "igo_ch_chk_done fail, error no : %d\n", retval);
            return IGO_CH_STATUS_BUSY;
        }

        if (time_after(jiffies, end_time)) {
            dev_err(dev, "igo cmd timeout\n");
            return IGO_CH_STATUS_TIMEOUT;
        }

        usleep_range(49, 50);
    }

    return status;
#endif
}

int igo_ch_write_wait(struct device *dev, unsigned int reg, unsigned int data, unsigned int wait_time)
{
#ifdef IGO_DUMMY_DRIVER
    return IGO_CH_STATUS_DONE;
#else
    struct i2c_client* client;
    uint32_t cmd[2];
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    int32_t retval = 0;

    client = i2c_verify_client(dev);
    cmd[0] = IGO_CH_STATUS_CMD_RDY;
    cmd[1] = (IGO_CH_ACTION_WRITE << IGO_CH_ACTION_OFFSET) + reg;

#ifdef IG_CH_CMD_USING_SPI
    if (debussy->spi_dev) {
        retval = igo_spi_write(IGO_CH_BUF_ADDR, data);
        if (0 != retval) {
            igo_spi_intf_enable(1);
            retval = igo_spi_write(IGO_CH_BUF_ADDR, data);
        }

        retval |= igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
        retval |= igo_spi_write(IGO_CH_STATUS_ADDR, cmd[0]);
    }
    else
#endif
    {
        retval = igo_i2c_write(client, IGO_CH_BUF_ADDR, data);
        retval |= igo_i2c_write(client, IGO_CH_CMD_ADDR, cmd[1]);
        retval |= igo_i2c_write(client, IGO_CH_STATUS_ADDR, cmd[0]);
    }

    if (0 != retval) {
        dev_err(dev, "igo cmd CH Write wait fail, error no : %d\n", reg);
        return IGO_CH_STATUS_BUSY;
    }

    if (wait_time) {
        if (wait_time < 20) {
            wait_time *= 1000;
            usleep_range(wait_time - 1, wait_time);
        }
        else {
            msleep(wait_time);
        }
    }

    status = igo_ch_chk_done(dev);

    if (status != IGO_CH_STATUS_DONE) {
        dev_err(dev, "igo cmd write 0x%08x : 0x%08x fail, error no : %d\n", reg, data, status);

#ifdef IGO_TIMEOUT_RESET_CHIP
        #if 0
        // All CMD
        if (IGO_CH_STATUS_TIMEOUT == status) {
            struct debussy_priv* debussy = i2c_get_clientdata(client);

            // Reset IGO chip while IGO CMD timeout occured
            debussy->mcu_hold(dev, 0);
            debussy->reset_chip(dev, 1, 0);
        }
        #else
        // Only power mode CMD
        if ((IGO_CH_STATUS_TIMEOUT == status) && (IGO_CH_POWER_MODE_ADDR == reg)) {
            // Force HW Reset about 40ms
            struct debussy_priv *debussy = i2c_get_clientdata(client);

            debussy->mcu_hold(dev, 0);
            debussy->reset_chip(dev, 1, 0);
        }
        #endif
#endif
    }

    return status;
#endif
}

int igo_ch_write(struct device *dev, unsigned int reg, unsigned int data)
{
    struct debussy_priv *debussy = i2c_get_clientdata(i2c_verify_client(dev));
    uint32_t noDelayAfterWrite = 0;

    switch (reg) {
    case IGO_CH_HIF_CALI_EN_ADDR:
        return igo_ch_write_wait(dev, reg, data, noDelayAfterWrite);
        break;

    case IGO_CH_POWER_MODE_ADDR:
#ifdef ENABLE_MASK_CONFIG_CMD
        if (POWER_MODE_WORKING == data) {
            atomic_add(1, &debussy->referenceCount);
            dev_info(dev, "%s: POWER_MODE_WORKING: ref = %d\n", __func__, atomic_read(&debussy->referenceCount));
            atomic_set(&debussy->maskConfigCmd, 0);
            dev_info(dev, "%s: POWER_MODE_WORKING: Disable mask configure setting\n", __func__);
        }
        else {
            // from debussy_shutdown or OP_MODE_CONFIG
            atomic_set(&debussy->maskConfigCmd, 1);
            dev_info(dev, "%s: POWER_MODE_STANDBY: Enable mask configure setting\n", __func__);

    #ifdef ENABLE_REFERENCE_COUNT
            if (atomic_read(&debussy->referenceCount)) {
                atomic_sub(1, &debussy->referenceCount);
            }
    #else
            atomic_set(&debussy->referenceCount, 1);
    #endif
            dev_info(dev, "%s: POWER_MODE_STANDBY: ref = %d\n", __func__, atomic_read(&debussy->referenceCount));

    #ifdef ENABLE_REFERENCE_COUNT
            if (atomic_read(&debussy->referenceCount)) {
                return IGO_CH_STATUS_DONE;
            }
    #endif
        }
#endif

#ifdef ENABLE_CMD_BATCH_MODE_BUFFERED
        if (IGO_CH_POWER_MODE_ADDR == reg) {
            atomic_set(&batchCmdNum, 0);

            if (POWER_MODE_WORKING == data) {
                atomic_set(&batchMode, 1);
                dev_info(dev, "%s: Enable batch CMD mode\n", __func__);
            }
            else {
                // POWER_MODE_STANDBY
                atomic_set(&batchMode, 0);
                dev_info(dev, "%s: Disable batch CMD mode\n", __func__);
            }
        }
#endif
        break;

    //case IGO_CH_OP_MODE_ADDR:
    default:
#ifdef ENABLE_MASK_CONFIG_CMD
        if (atomic_read(&debussy->maskConfigCmd)) {
            return IGO_CH_STATUS_DONE;
        }

        if (IGO_CH_OP_MODE_ADDR == reg) {
            if (OP_MODE_CONFIG == data) {
                // debussy_shutdown is ignored, change to Standby CMD
                reg = IGO_CH_POWER_MODE_ADDR;
                data = POWER_MODE_STANDBY;
                break;
            }
        }
#endif

#ifdef ENABLE_CMD_BATCH_MODE_BUFFERED
        if (atomic_read(&batchMode)) {
            int status = IGO_CH_STATUS_DONE;
            uint32_t index = atomic_read(&batchCmdNum) << 1;

            batch_cmd_buffer[index] = reg;
            batch_cmd_buffer[index + 1] = data;
            atomic_add(1, &batchCmdNum);

            if ((atomic_read(&batchCmdNum) >= MAX_BATCH_MODE_CMD_NUM) || (IGO_CH_OP_MODE_ADDR == reg)) {
                if (0 == igo_ch_batch_write(dev, 0, batch_cmd_buffer, atomic_read(&batchCmdNum) << 1)) {
                    status = igo_ch_batch_finish_write(dev, atomic_read(&batchCmdNum));
                    atomic_set(&batchCmdNum, 0);
                    dev_info(dev, "%s: igo_ch_batch_finish_write ret = %d\n", __func__,status);

                    if (IGO_CH_OP_MODE_ADDR == reg) {
                        atomic_set(&batchMode, 0);
                        dev_info(dev, "%s: IGO_CH_OP_MODE_ADDR: Disable batch mode\n", __func__);
                    }
                }
                else {
                    dev_info(dev, "%s: BatchMode write fail\n", __func__);
                    status = IGO_CH_STATUS_BUSY;
                }
            }
            else {
                dev_info(dev, "%s: BatchMode without write \n", __func__);
            }

            return status;
        }
#endif
        break;
    }

    if (IGO_CH_POWER_MODE_ADDR == reg) {
        if (POWER_MODE_STANDBY == data) {
#ifdef HW_RESET_INSTEAD_OF_STANDBY
            dev_info(dev, "%s: POWER_MODE_STANDBY: HW_RESET_INSTEAD_OF_STANDBY\n", __func__);
            // about 40ms
            debussy->mcu_hold(dev, 0);
            #ifdef IGO_STANDBY_INSTEAD_OF_DELAY_WORK
            debussy->reset_chip(dev, 1, 1);
            #else
            debussy->reset_chip(dev, 1, 0);
            #endif

            return IGO_CH_STATUS_DONE;
#endif
        }

        noDelayAfterWrite = 20;
        dev_info(dev, "%s: POWER_MODE_WORKING: set noDelayAfterWrite = %d \n", __func__,noDelayAfterWrite);
    }

    return igo_ch_write_wait(dev, reg, data, noDelayAfterWrite);
}

int igo_ch_read(struct device *dev, unsigned int reg, unsigned int *data)
{
    struct i2c_client* client;
    uint32_t cmd[2];
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    int32_t retval = 0;

    client = i2c_verify_client(dev);

    cmd[0] = status;
    cmd[1] = (IGO_CH_ACTION_READ << IGO_CH_ACTION_OFFSET) + reg;

#ifdef IG_CH_CMD_USING_SPI
    if (debussy->spi_dev) {
        retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
        if (0 != retval) {
            igo_spi_intf_enable(1);
            retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
        }

        retval |= igo_spi_write(IGO_CH_STATUS_ADDR, cmd[0]);
    }
    else
#endif
    {
        retval = igo_i2c_write(client, IGO_CH_CMD_ADDR, cmd[1]);
        retval |= igo_i2c_write(client, IGO_CH_STATUS_ADDR, cmd[0]);
    }

    if (0 != retval) {
        dev_err(dev, "igo cmd I2C Write fail, error no : %d\n", reg);
        *data = 0;

        return IGO_CH_STATUS_BUSY;
    }

    status = igo_ch_chk_done(dev);

    if (status != IGO_CH_STATUS_DONE) {
        dev_err(dev, "igo cmd read 0x%08x fail, error no : %d\n", reg, status);
        *data = 0;
    }
    else {
#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            igo_spi_read(IGO_CH_BUF_ADDR, data);
        }
        else
#endif
        {
            igo_i2c_read(client, IGO_CH_BUF_ADDR, data);
        }
    }

    return status;
}

#ifdef ENABLE_CMD_BATCH_MODE_BUFFERED
int igo_ch_batch_write(struct device *dev, unsigned int cmd_index, unsigned int *data, unsigned int data_length)
{
    struct i2c_client* client;
    struct debussy_priv *debussy;

    client = i2c_verify_client(dev);
    debussy = i2c_get_clientdata(client);

#ifdef IG_CH_CMD_USING_SPI
    if (debussy->spi_dev) {
        int32_t retval = 0;

        retval = igo_spi_write_buffer(IGO_CH_BUF_ADDR + (cmd_index << 3), data, data_length);
        if (0 != retval) {
            igo_spi_intf_enable(1);
            return igo_spi_write_buffer(IGO_CH_BUF_ADDR + (cmd_index << 3), data, data_length);
        }

        return retval;
    }
#endif

    return igo_i2c_write_buffer(client, IGO_CH_BUF_ADDR + (cmd_index << 3), data, data_length);
}

int igo_ch_batch_finish_write(struct device *dev, unsigned int num_of_cmd)
{
    struct i2c_client* client;
    uint32_t cmd[2];
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    int32_t retval = 0;

    client = i2c_verify_client(dev);
    cmd[0] = IGO_CH_STATUS_CMD_RDY;
    cmd[1] = (IGO_CH_ACTION_BATCH << IGO_CH_ACTION_OFFSET) + num_of_cmd;

#ifdef IG_CH_CMD_USING_SPI
    if (debussy->spi_dev) {
        retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
        if (0 != retval) {
            igo_spi_intf_enable(1);
            retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
        }

        retval |= igo_spi_write(IGO_CH_STATUS_ADDR, cmd[0]);
    }
    else
#endif
    {
        retval = igo_i2c_write(client, IGO_CH_CMD_ADDR, cmd[1]);
        retval |= igo_i2c_write(client, IGO_CH_STATUS_ADDR, cmd[0]);
    }

    if (0 != retval) {
        dev_err(dev, "%s: igo ch batch finish write fail\n", __func__);

        return IGO_CH_STATUS_BUSY;
    }

    status = igo_ch_chk_done(dev);

    if (status != IGO_CH_STATUS_DONE) {
        dev_err(dev, "igo batch cmd write fail, error no : %d\n", status);
#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            igo_spi_read(IGO_CH_RSV_ADDR, &cmd[0]);
        }
        else
#endif
        {
            igo_i2c_read(client, IGO_CH_RSV_ADDR, &cmd[0]);
        }

        dev_err(dev, "igo cmd batch finish write fail: error bit 0x%08X\n", cmd[0]);

#ifdef IGO_TIMEOUT_RESET_CHIP
        // All CMD
        if (IGO_CH_STATUS_TIMEOUT == status) {
            struct debussy_priv *debussy = i2c_get_clientdata(client);

            // Reset IGO chip while IGO CMD timeout occured
            debussy->mcu_hold(dev, 0);
            debussy->reset_chip(dev, 1, 0);
        }
#endif
    }

    return status;
}
#endif

int igo_ch_buf_write(struct device *dev, unsigned int addr, unsigned int *data, unsigned int word_len) {
    struct i2c_client *client;
    struct debussy_priv *debussy;
    uint32_t cmd[2];
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    uint32_t writeSize, writeSize_bytes, offset = 0;
    int32_t retval = 0;

    client = i2c_verify_client(dev);
    debussy = i2c_get_clientdata(client);

    while (word_len) {
        writeSize = (word_len >= (IG_BUF_RW_LEN >> 2)) ? (IG_BUF_RW_LEN >> 2) : word_len;
        writeSize_bytes = writeSize << 2;

#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            retval = igo_spi_write_buffer(IGO_CH_BUF_ADDR, &data[offset], writeSize);
            if (0 != retval) {
                igo_spi_intf_enable(1);
                retval = igo_spi_write_buffer(IGO_CH_BUF_ADDR, &data[offset], writeSize);
            }
        }
        else
#endif
        {
            retval = igo_i2c_write_buffer(client, IGO_CH_BUF_ADDR, &data[offset], writeSize);
        }

        if (0 != retval) {
            dev_err(dev, "%s: igo cmd CH Buf Write fail, error no : %d\n", __func__, retval);

            return IGO_CH_STATUS_BUSY;
        }

        cmd[0] = IGO_CH_STATUS_CMD_RDY;
        cmd[1] = (IGO_CH_ACTION_WRITE << IGO_CH_ACTION_OFFSET) + addr;

#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
            if (0 != retval) {
                igo_spi_intf_enable(1);
                retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
            }

            retval |= igo_spi_write(IGO_CH_OPT_ADDR, writeSize_bytes);
            retval |= igo_spi_write(IGO_CH_STATUS_ADDR, cmd[0]);
        }
        else
#endif
        {
            retval = igo_i2c_write(client, IGO_CH_CMD_ADDR, cmd[1]);
            retval |= igo_i2c_write(client, IGO_CH_OPT_ADDR, writeSize_bytes);
            retval |= igo_i2c_write(client, IGO_CH_STATUS_ADDR, cmd[0]);
        }

        if (0 != retval) {
            dev_err(dev, "%s: igo cmd buff Write fail, Addr : 0x%08X\n", __func__, addr);

            return IGO_CH_STATUS_BUSY;
        }

        status = igo_ch_chk_done(dev);

        if (status != IGO_CH_STATUS_DONE) {
            dev_err(dev, "igo ch buffer write fail, error no : %d\n", status);

#ifdef IGO_TIMEOUT_RESET_CHIP
            if (IGO_CH_STATUS_TIMEOUT == status) {
                struct debussy_priv *debussy = i2c_get_clientdata(client);

                // Reset IGO chip while IGO CMD timeout occured
                debussy->mcu_hold(dev, 0);
                debussy->reset_chip(dev, 1, 0);
            }
#endif

            return status;
        }

        addr += writeSize << 2;
        word_len -= writeSize;
        offset += writeSize;
    }

    return status;
}

int igo_ch_buf_read(struct device *dev, unsigned int addr, unsigned int *data, unsigned int word_len) {
    struct i2c_client* client = i2c_verify_client(dev);
    uint32_t cmd[2];
    uint32_t status = IGO_CH_STATUS_CMD_RDY;
    uint32_t read_size, read_size_byte, offset = 0;
#if defined(IG_CH_CMD_USING_SPI) || defined(IGO_TIMEOUT_RESET_CHIP)
    struct debussy_priv *debussy = i2c_get_clientdata(client);
#endif
    int retval;

    while (word_len) {
        read_size = (word_len >= (IG_BUF_RW_LEN >> 2)) ? (IG_BUF_RW_LEN >> 2) : word_len;
        read_size_byte = read_size << 2;

        cmd[0] = IGO_CH_STATUS_CMD_RDY;
        cmd[1] = (IGO_CH_ACTION_READ << IGO_CH_ACTION_OFFSET) + addr;

#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            if (0 != igo_spi_write(IGO_CH_CMD_ADDR, cmd[1])) {
                igo_spi_intf_enable(1);
                retval = igo_spi_write(IGO_CH_CMD_ADDR, cmd[1]);
            }

            retval |= igo_spi_write(IGO_CH_OPT_ADDR, read_size_byte);
            retval |= igo_spi_write(IGO_CH_STATUS_ADDR, cmd[0]);
        }
        else
#endif
        {
            retval = igo_i2c_write(client, IGO_CH_CMD_ADDR, cmd[1]);
            retval |= igo_i2c_write(client, IGO_CH_OPT_ADDR, read_size_byte);
            retval |= igo_i2c_write(client, IGO_CH_STATUS_ADDR, cmd[0]);
        }

        if (0 != retval) {
            dev_err(dev, "%s: igo ch buf read fail, error no : %d\n", __func__, retval);

            return IGO_CH_STATUS_BUSY;
        }

        status = igo_ch_chk_done(dev);

        if (status != IGO_CH_STATUS_DONE) {
            dev_err(dev, "igo ch buffer read fail, error no : %d\n", status);

#ifdef IGO_TIMEOUT_RESET_CHIP
            // All CMD
            if (IGO_CH_STATUS_TIMEOUT == status) {
                // Reset IGO chip while IGO CMD timeout occured
                debussy->mcu_hold(dev, 0);
                debussy->reset_chip(dev, 1, 0);
            }
#endif

            return status;
        }

#ifdef IG_CH_CMD_USING_SPI
        if (debussy->spi_dev) {
            igo_spi_read_buffer(IGO_CH_BUF_ADDR, &data[offset], read_size);
        }
        else
#endif
        {
            igo_i2c_read_buffer(client, IGO_CH_BUF_ADDR, &data[offset], read_size);
        }

        word_len -= read_size;
        offset += read_size;
        addr += read_size << 2;
    }

    return status;
}
