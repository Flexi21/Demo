#include "debussy.h"
#include "debussy_customer.h"
#include <linux/regulator/consumer.h>

#define IGO_POWER_GPIO  (-2)

static int32_t power_gpio = IGO_POWER_GPIO;

void debussy_power_enable(int enable) {
    if (enable) {
        // Turn on Power for IG
       /*
	if (gpio_is_valid(power_gpio)) {
	 	gpio_direction_output(power_gpio, GPIO_HIGH);
		gpio_set_value(power_gpio, GPIO_HIGH);
		dev_err(p_debussy_priv->dev, "IGO_POWER: enable");
	}*/
    }
    else {
        // Turn off power for IG
     /*
    if (gpio_is_valid(power_gpio)) {
        gpio_direction_output(power_gpio, GPIO_LOW);
        gpio_set_value(power_gpio, GPIO_LOW);
     // usleep_range(IGO_RST_RELEASE_INIT_TIME - 1, IGO_RST_RELEASE_INIT_TIME);
		dev_err(p_debussy_priv->dev, "IGO_POWER: disable");
        }*/
    }
}

void debussy_mic_bias_enable(int enable) {
	static struct regulator *vdd_micbias;
	int ret;
	if (!vdd_micbias) {
		vdd_micbias = regulator_get(NULL, "MICBIAS");
		if (IS_ERR(vdd_micbias)) {
		printk("debussy regulator get of vdd_micbias failed");
		ret = PTR_ERR(vdd_micbias);
		vdd_micbias = NULL;
		return;
	}
	regulator_set_voltage(vdd_micbias, 2400000, 2400000);
	}
    if (0 != enable) {
        // Turnon MIC BIAS
        if(!regulator_is_enabled(vdd_micbias))
		regulator_enable(vdd_micbias);
		//printk("debussy regulator enable of vdd_micbias ok");
    }
    else {
        // Turnoff MIC BIAS
	if(regulator_is_enabled(vdd_micbias))
	{
        ret = regulator_disable(vdd_micbias);
        regulator_put(vdd_micbias);
	 vdd_micbias =0;
	}
	 //printk("debussy regulator disable of vdd_micbias ok");
    }
}

static int enable_mclk_times = 0;
void debussy_bb_clk_enable(int enable) 
{
	static struct clk * clk_aux0;
	static struct clk * clk_parent;
	static struct clk * clk_aux0_eb;
    if (0 != enable) 
    {
        // Enable BB MCLK Output, like 19.2MHz

    //mclk
    	clk_aux0 = clk_get(NULL,"clk_aux0");
    	if(IS_ERR(clk_aux0)) 
	{
        	pr_err("can't get clk_aux0 clock \n ");
        	return;
    	}

    	clk_parent = clk_get(NULL,"clk_twpll_48m");//clk_twpll_48m
    	if(IS_ERR(clk_parent)) 
	{
        	pr_err("can't get clk_parent clock \n ");
        	return;
    	}

    	clk_aux0_eb = clk_get(NULL, "aux0_eb");
    	if(IS_ERR(clk_aux0_eb)) 
	{
	        pr_err("can't get clk_aux0_eb clock \n ");
	        return;
	}

    	clk_set_parent(clk_aux0,clk_parent);
    	clk_set_rate(clk_aux0,48000000);    //48000000            /* Mclk = 48MHz */
    	clk_prepare_enable(clk_aux0);
    	clk_prepare_enable(clk_aux0_eb);
		enable_mclk_times++;
		printk("debussy_do@%d Set MCLK = 48MHz clock OK. \n",enable_mclk_times);
    }
    else 
    {
        // Disable BB MCLK Output, like 19.2MHz
	if (!IS_ERR(clk_aux0)) 
	{
		clk_disable_unprepare(clk_aux0);
		clk_put(clk_aux0);
	}
	if (!IS_ERR(clk_aux0_eb)) 
	{
		clk_disable_unprepare(clk_aux0_eb);
		clk_put(clk_aux0_eb);
	}
    }
}

void debussy_kws_int_handler_enter(struct debussy_priv *debussy, int irq, void *data) {
    #ifdef KWS_INT_LEVEL_TRIGGER
    disable_irq_nosync(irq);
    #endif
}

void debussy_kws_hit(void) {
    // Info launcher or system service to load specified APP.
}

void debussy_kws_int_handler_finish(struct debussy_priv *debussy, u32 kws_irq) {
    #ifdef KWS_INT_LEVEL_TRIGGER
    enable_irq(kws_irq);
    #endif
}

void debussy_dts_table_cus(struct debussy_priv *debussy, struct device_node *node) {
//add by chuang start
	static struct regulator *vddcamd;
	int ret;

	power_gpio = of_get_named_gpio(node, "ig,debussy-en", 0);
    if (power_gpio < 0) {
        dev_err(debussy->dev, "Unable to get \"ig,debussy-en\"\n");
        power_gpio = IGO_POWER_GPIO;
    }
    else {
        printk( "power_enable = %d\n", power_gpio);
    }

    if (gpio_is_valid(power_gpio)) {
        if (0 == gpio_request(power_gpio, "IGO_POWER")) {
            gpio_direction_output(power_gpio, GPIO_HIGH);
            gpio_set_value(power_gpio, GPIO_HIGH);
		 dev_err(debussy->dev, "IGO_POWER: gpio_request ok\n");
        }
        else {
            dev_err(debussy->dev, "IGO_POWER: gpio_request fail\n");
        }
    }
    else {
        dev_err(debussy->dev, "power_gpio is invalid: %d\n", power_gpio);
    }


	if (!vddcamd) {
		vddcamd = regulator_get(NULL, "vddcamd");
		if (IS_ERR(vddcamd)) {
		printk("debussy regulator get of vddcamd failed");
		ret = PTR_ERR(vddcamd);
		vddcamd = NULL;
		return;
	}
	regulator_set_voltage(vddcamd, 1200000, 1200000);
	}

        // Turnon vddcamd
        if(!regulator_is_enabled(vddcamd))
		regulator_enable(vddcamd);
		printk("debussy regulator enable of vddcamd ok");

//add by chang end
}
