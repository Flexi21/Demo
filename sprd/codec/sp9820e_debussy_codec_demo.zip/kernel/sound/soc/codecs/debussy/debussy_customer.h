#ifndef DEBUSSY_CUSTOMER_H
#define DEBUSSY_CUSTOMER_H

#include "debussy.h"

// #define KWS_INT_LEVEL_TRIGGER
// #define KWS_INT_DEBUSSY_STANDBY
#define DOWNLOAD_FW_USING_HEADER_FILE

#define CLK_CALI_INTERVAL       (500)       //ms

extern void debussy_power_enable(int);
extern void debussy_mic_bias_enable(int);
extern void debussy_bb_clk_enable(int);

extern void debussy_kws_int_handler_enter(struct debussy_priv *, int, void *);
extern void debussy_kws_hit(void);
extern void debussy_kws_int_handler_finish(struct debussy_priv *debussy, u32 kws_irq);
extern void debussy_dts_table_cus(struct debussy_priv *, struct device_node *);

#endif
