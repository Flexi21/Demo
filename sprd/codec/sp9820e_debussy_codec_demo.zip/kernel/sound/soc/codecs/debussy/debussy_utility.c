#include <linux/version.h>
#include <linux/slab.h>
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/firmware.h>
#include <linux/gpio.h>
#include <linux/i2c.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/pm.h>
#include <linux/string.h>
#include <sound/core.h>
#include <sound/initval.h>
#include <sound/soc.h>
#include <sound/tlv.h>

#include "debussy.h"

void memcpy_u32(uint32_t *target, uint32_t *src, uint32_t word_len) {
    uint32_t i;

    for (i = 0; i < word_len; i++) {
        *(target + i) = *(src + i);
    }
}

void memset_u32(uint32_t *target, uint32_t data, uint32_t word_len) {
    uint32_t i;

    for (i = 0; i < word_len; i++) {
        *(target + i) = data;
    }
}

void endian_swap(uint32_t *target, uint32_t *source, uint32_t word_len) {
    uint32_t i;
    uint32_t temp;

    for (i = 0; i < word_len; i++) {
        temp =  (source[i] >> 24) & 0x000000FF;
        temp += (source[i] >>  8) & 0x0000FF00;
        temp += (source[i] <<  8) & 0x00FF0000;
        temp += (source[i] << 24) & 0xFF000000;
        target[i] = temp;
    }
}
